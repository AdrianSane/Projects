(function (lib, img, cjs, ss, an) {

var p; // shortcut to reference prototypes
lib.ssMetadata = [];


// symbols:



(lib.BlueGradientImage = function() {
	this.initialize(img.BlueGradientImage);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,160,600);


(lib.img_athlete = function() {
	this.initialize(img.img_athlete);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,240,704);


(lib.img_facilities = function() {
	this.initialize(img.img_facilities);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,240,900);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.shape_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0072B8").s().p("EgoEAO2MAmfgw1MgcPA1MMAq8g7EMgV9AwiIqOV7MAyfhN7MghZBWnILv1IMAaOguuMgWjBF/IAEAAMAakg2QMgQ8A70Mgn+AAWg");
	this.shape.setTransform(256.5,303);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.shape_0, new cjs.Rectangle(0,0,513,605.9), null);


(lib.textheadline3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ABkG6IjAonIgDAAIAAInIiJAAIAAtzICNAAIC4H5IADAAIAAn5ICJAAIAANzg");
	this.shape.setTransform(67.5,482.4,0.429,0.429);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AjTG6IAAtzIGWAAIAACEIj+AAIAADkIDDAAIAACDIjDAAIAAEEIEPAAIAACEg");
	this.shape_1.setTransform(43.2,482.4,0.429,0.429);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AiCBYIBgivIClAAIifCvg");
	this.shape_2.setTransform(131.5,456.5,0.429,0.429);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AivGDQg5g8AAhkIAAnGQAAhjA5g8QA+hDBxAAQByAAA+BDQA4A8AABjIAAHGQAABkg4A8Qg+BDhyAAQhxAAg+hDgAg/kpQgRAXAAAzIAAG/QAAAzARAWQAUAYArAAQAsAAATgYQARgWAAgzIAAm/QAAgzgRgXQgTgYgsAAQgrAAgUAYg");
	this.shape_3.setTransform(125.8,482.4,0.429,0.429);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("ABuG6IgbjEIilAAIgbDEIiTAAICjtzIC7AAICjNzgAg8ByIB5AAIg8l7IgBAAg");
	this.shape_4.setTransform(280.2,482.4,0.429,0.429);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AjTG6IAAtzIGWAAIAACEIj+AAIAADkIDDAAIAACDIjDAAIAAEEIEPAAIAACEg");
	this.shape_5.setTransform(256.6,482.4,0.429,0.429);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AiqF+Qg6hEgFhoICQgVQAFBBAYAjQAYAhAlAAQApAAAXgUQAYgWAAgmQAAg6gwg3QgUgXhVhJQhJg9ghgwQgwhIAAhVQAAhqA9g5QA+g6BvAAQBaAAA4A9QA2A5AKBhIiQAQQgEg0gagaQgVgUgeAAQgkAAgTAXQgUAWAAAqQAAAxAwA1QARASBZBOQBIA+AiAyQAwBHAABRQAABrhDA9QhAA7hsAAQhmAAg/hJg");
	this.shape_6.setTransform(233,482.4,0.429,0.429);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AjTG6IAAtzIGWAAIAACEIj+AAIAADkIDDAAIAACDIjDAAIAAEEIEPAAIAACEg");
	this.shape_7.setTransform(200.8,482.4,0.429,0.429);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AjoG6IAAtzIDiAAQDvAAAAELIAAFdQAAELjvAAgAhQE9IA1AAQA8AAAYgbQAYgbAAhFIAAmDQAAhFgYgbQgYgbg8AAIg1AAg");
	this.shape_8.setTransform(176.5,482.4,0.429,0.429);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("ABlG6IjBonIgDAAIAAInIiJAAIAAtzICNAAIC4H5IACAAIAAn5ICKAAIAANzg");
	this.shape_9.setTransform(151.1,482.4,0.429,0.429);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AjoG6IAAtzIDiAAQDvAAAAELIAAFdQAAELjvAAgAhQE9IA1AAQA8AAAYgbQAYgbAAhFIAAmDQAAhFgYgbQgYgbg8AAIg1AAg");
	this.shape_10.setTransform(100.6,482.4,0.429,0.429);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("ABuHmIjTpeIgDAAIAAJeIiXAAIAAvKICbAAIDKIqIADAAIAAoqICXAAIAAPKg");
	this.shape_11.setTransform(280.3,291.5,0.429,0.429);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AjBGqQg9hCgBhtIAAn0QABhtA9hDQBEhJB9AAQB+AABDBJQA/BDgBBtIAAH0QABBtg/BCQhDBJh+AAQh9AAhEhJgAhFlGQgTAYAAA5IAAHrQAAA4ATAZQAVAbAwAAQAxAAAVgbQATgZAAg4IAAnrQAAg5gTgYQgVgbgxAAQgwAAgVAbg");
	this.shape_12.setTransform(252.6,291.5,0.429,0.429);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("Ai8GqQg+hCAAhtIAAn0QAAhtA+hDQBEhJB8AAQB4AABCBOQA9BJAABzIAABHIimAAIAAhKQAAg7gZgfQgVgcgjAAQgwAAgUAbQgUAYAAA5IAAHrQAAA4AUAZQAUAbAwAAQAsAAATgaQASgXAAgyIAAh1ICmAAIAABxQAABsg9BDQhCBJh4AAQh8AAhEhJg");
	this.shape_13.setTransform(224.9,291.5,0.429,0.429);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AB5HmIgejYIi2AAIgdDYIihAAICyvKIDPAAICzPKgAhCB9ICFAAIhCmgIgCAAg");
	this.shape_14.setTransform(187.3,291.5,0.429,0.429);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AkNHmIAAvKIDvAAQCcAABHBBQBJBEAACZQAACZhJBDQhHBCicAAIhJAAIAAGOgAhngxIBBAAQBRABAeggQAfgfAAhXQAAhWgfggQgegfhRgBIhBAAg");
	this.shape_15.setTransform(162.3,291.5,0.429,0.429);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("ADBHmIAAr2IgCAAIiXL2IhQAAIiWr2IgDAAIAAL2IiRAAIAAvKIDbAAIB2I2IADAAIB2o2IDbAAIAAPKg");
	this.shape_16.setTransform(130.4,291.5,0.429,0.429);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AB5HmIgejYIi1AAIgeDYIihAAICzvKIDOAAICyPKgAhCB9ICGAAIhDmgIgBAAg");
	this.shape_17.setTransform(99.6,291.5,0.429,0.429);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("Ai8GqQg/hCAAhtIAAn0QAAhtA/hDQBEhJB8AAQB4AABCBOQA+BJAABzIAABHIinAAIAAhKQAAg7gYgfQgWgcgjAAQgwAAgVAbQgTAYAAA5IAAHrQAAA4ATAZQAVAbAwAAQAsAAATgaQASgXAAgyIAAh1ICnAAIAABxQAABsg+BDQhCBJh4AAQh8AAhEhJg");
	this.shape_18.setTransform(72.8,291.5,0.429,0.429);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AB5HmIgdjYIi3AAIgdDYIiiAAIC0vKIDOAAICzPKgAhCB9ICFAAIhBmgIgDAAg");
	this.shape_19.setTransform(46.3,291.5,0.429,0.429);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AlTLGIAA2KIKMAAIAADUImYAAIAAFtIE5AAIAADUIk5AAIAAGgIGzAAIAADVg");
	this.shape_20.setTransform(276.7,418.7,0.429,0.429);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("Ah5LGIAAy2IjsAAIAAjUILLAAIAADUIjsAAIAAS2g");
	this.shape_21.setTransform(240.4,418.7,0.429,0.429);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("Ah5LGIAA2KIDzAAIAAWKg");
	this.shape_22.setTransform(212.8,418.7,0.429,0.429);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AmKLGIAA2KIFeAAQDkAABoBgQBrBiAADgQAADghrBhQhoBgjkAAIhrAAIAAJHgAiXhIIBfAAQB3AAAsgtQAtgvAAh+QAAh+gtgvQgsgth3AAIhfAAg");
	this.shape_23.setTransform(182.4,418.7,0.429,0.429);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AEbLGIAAxUIgEAAIjcRUIh1AAIjcxUIgEAAIAARUIjUAAIAA2KIFAAAICtM8IADAAICts8IFAAAIAAWKg");
	this.shape_24.setTransform(135.8,418.7,0.429,0.429);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AkZJuQhbhhAAigIAAraQAAifBbhhQBjhrC2AAQC3AABkBrQBaBhABCfIAALaQgBCghaBhQhkBri3AAQi2AAhjhrgAhlndQgcAkAABTIAALOQAABSAcAkQAeAmBHAAQBHAAAegmQAdgkAAhSIAArOQAAhTgdgkQgegnhHAAQhHAAgeAng");
	this.shape_25.setTransform(90.3,418.7,0.429,0.429);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AkUJuQhbhhAAigIAAraQAAifBbhhQBkhrC2AAQCvAABhBzQBaBpAACpIAABoIj0AAIAAhuQAAhVgkgtQgfgpgzAAQhHAAgeAnQgcAkAABTIAALOQAABSAcAkQAeAmBHAAQBAABAcgmQAaghAAhJIAAirID0AAIAACjQAACfhaBiQhhBrivAAQi2AAhkhrg");
	this.shape_26.setTransform(49.9,418.7,0.429,0.429);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AjlIDQhPhcgHiNIDDgcQAGBZAiAvQAgAtAyAAQA2AAAggcQAhgdAAg1QAAhNhBhKQgcgghyhhQhjhTgthBQhBhhAAhzQAAiOBThOQBThNCWAAQB6AABMBRQBIBNAPCDIjDAVQgGhGgjgiQgcgcgoAAQgxAAgaAfQgbAfAAA4QAABCBBBHQAXAZB4BpQBhBUAuBDQBBBgAABtQAACRhaBSQhYBPiRAAQiJAAhVhig");
	this.shape_27.setTransform(278.2,346.2,0.429,0.429);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AjsILQhNhSAAiGIAApmQAAiGBNhSQBThZCZAAQCZAABVBZQBMBSAACGIAAJmQAACGhMBSQhVBaiZAAQiZAAhThagAhUmRQgYAeAABFIAAJcQAABGAYAeQAYAhA8AAQA8AAAaghQAXgeAAhGIAApcQAAhFgXgeQgaghg8AAQg8AAgYAhg");
	this.shape_28.setTransform(245.2,346.2,0.429,0.429);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AB8JVIiQnuQgmAEhEAAIAAHqIjNAAIAAyoIEfAAQCvgBBUBRQBXBVAAC6QAACEgtBPQglA9g9AdICtIcgAh+g8IBIAAQBUAAAhgnQAigoAAhpQAAhpgigoQghgmhUAAIhIAAg");
	this.shape_29.setTransform(211.9,346.2,0.429,0.429);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AhmJVIAAv2IjGAAIAAiyIJZAAIAACyIjHAAIAAP2g");
	this.shape_30.setTransform(179.4,346.2,0.429,0.429);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AjtILQhMhSAAiGIAApmQAAiGBMhSQBUhZCZAAQCaAABTBZQBNBSAACGIAAJmQAACGhNBSQhTBaiaAAQiZAAhUhagAhVmRQgXAeAABFIAAJcQAABGAXAeQAaAhA7AAQA8AAAZghQAYgeAAhGIAApcQAAhFgYgeQgZghg8AAQg7AAgaAhg");
	this.shape_31.setTransform(147.8,346.2,0.429,0.429);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AjlIDQhPhcgHiNIDDgcQAGBZAiAvQAfAtAyAAQA3AAAggcQAggdAAg1QAAhNhBhKQgbgghzhhQhjhTgshBQhBhhAAhzQAAiOBThOQBThNCWAAQB6AABMBRQBIBNAPCDIjDAVQgGhGgjgiQgcgcgpAAQgwAAgaAfQgbAfAAA4QAABCBBBHQAXAZB4BpQBhBUAuBDQBBBgAABtQAACRhaBSQhYBPiRAAQiJAAhVhig");
	this.shape_32.setTransform(114.7,346.2,0.429,0.429);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AjtILQhMhSAAiGIAApmQAAiGBMhSQBUhZCZAAQCaAABTBZQBNBSAACGIAAJmQAACGhNBSQhTBaiaAAQiZAAhUhagAhVmRQgXAeAABFIAAJcQAABGAXAeQAaAhA7AAQA8AAAZghQAYgeAAhGIAApcQAAhFgYgeQgZghg8AAQg7AAgaAhg");
	this.shape_33.setTransform(81.7,346.2,0.429,0.429);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("ACHJVIkEroIgDAAIAALoIi5AAIAAyoIC+AAID4KpIAEAAIAAqpIC5AAIAASog");
	this.shape_34.setTransform(47.6,346.2,0.429,0.429);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.textheadline3, new cjs.Rectangle(0,0,320,1200), null);


(lib.textheadline2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhtBKIBSiTICJAAIiGCTg");
	this.shape.setTransform(103.7,95.2,0.434,0.434);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AimA/QAXh4BTAAQAQAAASAGQAJADAWAKIAeAOQASAHAOAAQAXAAAKgLQAJgLABgXIA5AAQgYB4hSAAQgZAAgogVQgUgKgLgDQgQgGgPAAQgXAAgKALQgJALgBAXg");
	this.shape_1.setTransform(122.3,95.7,0.434,0.434);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("ABUFzIihnPIgCAAIAAHPIhzAAIAArlIB2AAICaGnIACAAIAAmnIBzAAIAALlg");
	this.shape_2.setTransform(122.4,118.1,0.434,0.434);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AixFzIAArlIFUAAIAABvIjUAAIAAC/ICjAAIAABuIijAAIAADaIDjAAIAABvg");
	this.shape_3.setTransform(102.3,118.1,0.434,0.434);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("ABcFzIgWilIiLAAIgWClIh8AAICJrlICdAAICJLlgAgyBfIBlAAIgyk9IgBAAg");
	this.shape_4.setTransform(274.7,118.1,0.434,0.434);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AijFzIAArlIB/AAIAAJ2IDIAAIAABvg");
	this.shape_5.setTransform(255.8,118.1,0.434,0.434);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AixFzIAArlIFUAAIAABvIjVAAIAAC/ICkAAIAABuIikAAIAADaIDkAAIAABvg");
	this.shape_6.setTransform(229.6,118.1,0.434,0.434);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AjCFzIAArlIC9AAQDIAAAADgIAAElQAADgjIAAgAhDEKIAsAAQAyAAAVgXQAUgWAAg7IAAlDQAAg7gUgXQgVgWgyAAIgsAAg");
	this.shape_7.setTransform(209,118.1,0.434,0.434);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AiwFzIAArlIFTAAIAABvIjUAAIAAC/ICjAAIAABuIijAAIAADaIDiAAIAABvg");
	this.shape_8.setTransform(180.3,118.1,0.434,0.434);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ag/FzIAAp2Ih7AAIAAhvIF1AAIAABvIh8AAIAAJ2g");
	this.shape_9.setTransform(161,118.1,0.434,0.434);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("ABcFzIgWilIiLAAIgWClIh8AAICJrlICdAAICJLlgAgyBfIBlAAIgyk9IgBAAg");
	this.shape_10.setTransform(143.7,118.1,0.434,0.434);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AiOFFQg0g0AAheIAAoqIB/AAIAAIvQAABRBDAAQBEAAAAhRIAAovIB/AAIAAIqQAABeg0A0QgzAzhcAAQhbAAgzgzg");
	this.shape_11.setTransform(81.5,118.3,0.434,0.434);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AjCFzIAArlIC9AAQDIAAAADgIAAElQAADgjIAAgAhDEKIAsAAQAzAAATgXQAVgXAAg6IAAlDQAAg7gVgXQgTgWgzAAIgsAAg");
	this.shape_12.setTransform(60.1,118.1,0.434,0.434);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("ABdFzIgXilIiLAAIgWClIh8AAICJrlICdAAICJLlgAgyBfIBlAAIgyk9IgBAAg");
	this.shape_13.setTransform(38.8,118.1,0.434,0.434);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AhtBKIBSiTICJAAIiGCTg");
	this.shape_14.setTransform(103.7,95.2,0.434,0.434);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AimA/QAXh4BTAAQAQAAASAGQAJADAWAKIAeAOQASAHAOAAQAXAAAKgLQAJgLABgXIA5AAQgYB4hSAAQgZAAgogVQgUgKgLgDQgQgGgPAAQgXAAgKALQgJALgBAXg");
	this.shape_15.setTransform(122.3,95.7,0.434,0.434);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AixFzIAArlIFUAAIAABvIjUAAIAAC/ICjAAIAABuIijAAIAADaIDjAAIAABvg");
	this.shape_16.setTransform(102.3,118.1,0.434,0.434);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("ABcFzIgWilIiLAAIgWClIh8AAICJrlICdAAICJLlgAgyBfIBlAAIgyk9IgBAAg");
	this.shape_17.setTransform(274.7,118.1,0.434,0.434);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AijFzIAArlIB/AAIAAJ2IDIAAIAABvg");
	this.shape_18.setTransform(255.8,118.1,0.434,0.434);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AixFzIAArlIFUAAIAABvIjVAAIAAC/ICkAAIAABuIikAAIAADaIDkAAIAABvg");
	this.shape_19.setTransform(229.6,118.1,0.434,0.434);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AjCFzIAArlIC9AAQDIAAAADgIAAElQAADgjIAAgAhDEKIAsAAQAyAAAVgXQAUgWAAg7IAAlDQAAg7gUgXQgVgWgyAAIgsAAg");
	this.shape_20.setTransform(209,118.1,0.434,0.434);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AiwFzIAArlIFTAAIAABvIjUAAIAAC/ICjAAIAABuIijAAIAADaIDiAAIAABvg");
	this.shape_21.setTransform(180.3,118.1,0.434,0.434);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("Ag/FzIAAp2Ih7AAIAAhvIF1AAIAABvIh8AAIAAJ2g");
	this.shape_22.setTransform(161,118.1,0.434,0.434);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("ABcFzIgWilIiLAAIgWClIh8AAICJrlICdAAICJLlgAgyBfIBlAAIgyk9IgBAAg");
	this.shape_23.setTransform(143.7,118.1,0.434,0.434);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AiOFFQg0g0AAheIAAoqIB/AAIAAIvQAABRBDAAQBEAAAAhRIAAovIB/AAIAAIqQAABeg0A0QgzAzhcAAQhbAAgzgzg");
	this.shape_24.setTransform(81.5,118.3,0.434,0.434);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AjCFzIAArlIC9AAQDIAAAADgIAAElQAADgjIAAgAhDEKIAsAAQAzAAATgXQAVgXAAg6IAAlDQAAg7gVgXQgTgWgzAAIgsAAg");
	this.shape_25.setTransform(60.1,118.1,0.434,0.434);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("ABdFzIgXilIiLAAIgWClIh8AAICJrlICdAAICJLlgAgyBfIBlAAIgyk9IgBAAg");
	this.shape_26.setTransform(38.8,118.1,0.434,0.434);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("ADDMNIgvlaIkmAAIgvFaIkEAAIEg4aIFMAAIEgYagAhrDJIDXAAIhqqeIgDAAg");
	this.shape_27.setTransform(270.3,174.5,0.434,0.434);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("ACPMNIAAq1IkdAAIAAK1IkMAAIAA4aIEMAAIAAJ9IEdAAIAAp9IEMAAIAAYag");
	this.shape_28.setTransform(225.6,174.5,0.434,0.434);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AkwKuQhkhsAAivIAAslQAAivBkhsQBuh1DIAAQDBAABrB/QBjB0AAC6IAAByIkNAAIAAh5QAAhdgngyQgigtg5AAQhOAAghArQgfAoAABaIAAMXQAABbAfAoQAhAqBOAAQBHAAAfgoQAcgmAAhQIAAi8IENAAIAAC0QAACuhjBtQhrB1jBAAQjIAAhuh1g");
	this.shape_29.setTransform(180.4,174.5,0.434,0.434);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("ACxMNIlVvPIgEAAIAAPPIjyAAIAA4aID4AAIFGN+IAFAAIAAt+IDyAAIAAYag");
	this.shape_30.setTransform(135.4,174.5,0.434,0.434);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("ADDMNIgwlaIklAAIgwFaIkEAAIEg4aIFNAAIEgYagAhrDJIDXAAIhqqeIgDAAg");
	this.shape_31.setTransform(90.6,174.5,0.434,0.434);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AkwKuQhkhsAAivIAAslQAAivBkhsQBuh1DIAAQDBAABsB/QBiB0AAC6IAAByIkMAAIAAh5QAAhdgogyQgigtg5AAQhOAAggArQggAnAABbIAAMXQAABbAgAoQAgAqBOAAQBHAAAfgoQAdgmAAhQIAAi8IEMAAIAAC0QAACuhiBtQhrB1jCAAQjIAAhuh1g");
	this.shape_32.setTransform(47,174.5,0.434,0.434);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.textheadline2, new cjs.Rectangle(29.5,92,260.6,117.5), null);


(lib.textheadline1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ah+BWIBeirICfAAIibCrg");
	this.shape.setTransform(114.1,90.8,0.433,0.433);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AjABJQAbiLBfAAQATAAAVAHQANAEAXAMIAjAPQAUAIAQAAQAaAAAMgNQALgMABgbIBCAAQgbCLhfAAQgTAAgVgHQgNgFgXgMQgsgWgbAAQgbAAgMANQgKAMgBAbg");
	this.shape_1.setTransform(135.4,91.3,0.433,0.433);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("ABhGsIi6oWIgCAAIAAIWIiFAAIAAtXICIAAICyHpIACAAIAAnpICFAAIAANXg");
	this.shape_2.setTransform(135.6,117,0.433,0.433);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ak4KwQhkhrAAixIAAsnQAAixBkhrQBuh2DKAAQDKAABuB2QBlBrAACxIAAMnQAACxhlBrQhuB2jKAAQjKAAhuh2gAhvoQQgfAoAABbIAAMbQAABaAfAoQAhArBOAAQBQAAAggrQAggoAAhaIAAsbQAAhbgggoQgggrhQAAQhOAAghArg");
	this.shape_3.setTransform(270.5,176.9,0.433,0.433);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("ACyMQIlWvTIgFAAIAAPTIjzAAIAA4fID6AAIFHOAIAFAAIAAuAIDzAAIAAYfg");
	this.shape_4.setTransform(225.2,176.9,0.433,0.433);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("ADEMQIgwlbIkmAAIgxFbIkFAAIEh4fIFPAAIEhYfgAhrDKIDYAAIhrqgIgDAAg");
	this.shape_5.setTransform(180.4,176.9,0.433,0.433);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("ACjMQIi+qJQg5AGhTABIAAKCIkNAAIAA4fIF6AAQDoAABtBqQBzBuAAD2QAACtg9BoQguBRhTAlIDlLGgAinhQIBgAAQBuABAsgzQAtg0AAiLQAAiKgtg1QgsgyhuAAIhgAAg");
	this.shape_6.setTransform(135.7,176.9,0.433,0.433);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Al3MQIAA4fILQAAIAADrInCAAIAAGUIFaAAIAADpIlaAAIAAHNIHhAAIAADqg");
	this.shape_7.setTransform(92.2,176.9,0.433,0.433);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AiGMQIlI4fIEJAAIDERAIADAAIDExAIEJAAIlIYfg");
	this.shape_8.setTransform(48.8,176.9,0.433,0.433);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ai8GsIAAtXICTAAIAALXIDmAAIAACAg");
	this.shape_9.setTransform(280.2,117,0.433,0.433);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AjMGsIAAtXIGIAAIAACAIj1AAIAADdIC8AAIAAB/Ii8AAIAAD7IEGAAIAACAg");
	this.shape_10.setTransform(258.8,117,0.433,0.433);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AjgGsIAAtXIDaAAQDnAAAAEDIAAFRQAAEDjnAAgAhNEzIAzAAQA5AAAYgaQAXgaAAhEIAAl1QAAhEgXgaQgYgag5AAIgzAAg");
	this.shape_11.setTransform(235,117,0.433,0.433);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AjMGsIAAtXIGIAAIAACAIj1AAIAADdIC9AAIAAB/Ii9AAIAAD7IEGAAIAACAg");
	this.shape_12.setTransform(202,117,0.433,0.433);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AhJGsIAArXIiOAAIAAiAIGuAAIAACAIiOAAIAALXg");
	this.shape_13.setTransform(179.9,117,0.433,0.433);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("ABqGsIgai+IifAAIgaC+IiPAAICetXIC1AAICeNXgAg6BuIB1AAIg6luIgBAAg");
	this.shape_14.setTransform(160,117,0.433,0.433);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AjMGsIAAtXIGIAAIAACAIj1AAIAADdIC9AAIAAB/Ii9AAIAAD7IEGAAIAACAg");
	this.shape_15.setTransform(112.5,117,0.433,0.433);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AikF3Qg8g7AAhuIAAp/ICTAAIAAKFQAABeBNAAQBOAAAAheIAAqFICTAAIAAJ/QAABug8A7Qg7A7hqAAQhpAAg7g7g");
	this.shape_16.setTransform(88.6,117.3,0.433,0.433);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AjgGsIAAtXIDaAAQDnAAAAEDIAAFRQAAEDjnAAgAhNEzIAzAAQA6AAAXgaQAXgaAAhEIAAl1QAAhEgXgaQgXgag6AAIgzAAg");
	this.shape_17.setTransform(64,117,0.433,0.433);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("ABqGsIgai+IigAAIgaC+IiOAAICetXIC1AAICeNXgAg6BuIB1AAIg6luIgBAAg");
	this.shape_18.setTransform(39.6,117,0.433,0.433);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.textheadline1, new cjs.Rectangle(28.8,87.1,259.6,124.7), null);


(lib.img_facilities_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.img_facilities();
	this.instance.parent = this;
	this.instance.setTransform(0,0,1.333,1.333);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.img_facilities_1, new cjs.Rectangle(0,0,320,1200), null);


(lib.logoartwork = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ag8CAIAAj/IB1AAIAAAXIhZAAIAABYIBBAAIAAAWIhBAAIAABjIBdAAIAAAXg");
	this.shape.setTransform(24.2,268.3,0.537,0.537);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhCCAIAAj/IAwAAQAqAAAUAbQAXAfAABFQAABGgXAfQgUAbgqAAgAgmBpIAPAAQAgAAAOgUQARgXAAg+QAAg9gRgXQgOgUggAAIgPAAg");
	this.shape_1.setTransform(15.5,268.3,0.537,0.537);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhIAAQAAiDBIAAQBIAAAACDQAACEhIAAQhIAAAAiEgAgfhWQgNAaAAA8QAAA9ANAaQALAVAUAAQAVAAALgVQAMgaAAg9QAAg8gMgaQgLgVgVAAQgUAAgLAVg");
	this.shape_2.setTransform(191.1,268.3,0.537,0.537);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgMCAIg8j/IAcAAIAsDKIABAAIAtjKIAbAAIg8D/g");
	this.shape_3.setTransform(182.6,268.3,0.537,0.537);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgNCAIAAj/IAbAAIAAD/g");
	this.shape_4.setTransform(176.7,268.3,0.537,0.537);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgNCAIAAjoIg0AAIAAgXICDAAIAAAXIg0AAIAADog");
	this.shape_5.setTransform(171.1,268.3,0.537,0.537);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAmCAIgoh5IglABIAAB4IgbAAIAAj/IA+AAQAeAAATARQAUASAAAfQAAAxgpANIArB/gAgngPIAZAAQAbAAANgLQALgLAAgWQAAgXgLgKQgNgMgbAAIgZAAg");
	this.shape_6.setTransform(163.2,268.3,0.537,0.537);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhHAAQgBiDBIAAQBIAAAACDQAACEhIAAQhIAAABiEgAgfhWQgNAaAAA8QAAA9ANAaQALAVAUAAQAVAAALgVQANgagBg9QABg8gNgaQgLgVgVAAQgUAAgLAVg");
	this.shape_7.setTransform(153.9,268.3,0.537,0.537);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("Ag/CAIAAj/IA8AAQAeAAATATQASATAAAgQAAAggSATQgTASgeAAIghAAIAAB0gAgkgKIAeAAQArAAAAgvQAAgvgrAAIgeAAg");
	this.shape_8.setTransform(145.5,268.3,0.537,0.537);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ag8CAIAAj/IB0AAIAAAXIhYAAIAABYIBBAAIAAAWIhBAAIAABjIBdAAIAAAXg");
	this.shape_9.setTransform(137.4,268.3,0.537,0.537);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AhCCAIAAj/IAvAAQAqAAAVAbQAXAfAABFQAABGgXAfQgVAbgqAAgAgnBpIAPAAQAgAAAOgUQARgXAAg+QAAg9gRgXQgOgUggAAIgPAAg");
	this.shape_10.setTransform(128.7,268.3,0.537,0.537);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AhIAAQAAiDBIAAQBIAAAACDQAACEhIAAQhIAAAAiEgAgehWQgOAaAAA8QAAA9AOAaQAKAVAUAAQAVAAALgVQANgaAAg9QAAg8gNgaQgLgVgVAAQgUAAgKAVg");
	this.shape_11.setTransform(117.1,268.3,0.537,0.537);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgNCAIAAjoIg1AAIAAgXICEAAIAAAXIg0AAIAADog");
	this.shape_12.setTransform(109.2,268.3,0.537,0.537);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAnCAIhPjeIAAAAIAADeIgcAAIAAj/IArAAIBCC8IAAAAIAAi8IAcAAIAAD/g");
	this.shape_13.setTransform(100.8,268.3,0.537,0.537);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("Ag8CAIAAj/IB1AAIAAAXIhZAAIAABYIBBAAIAAAWIhBAAIAABjIBdAAIAAAXg");
	this.shape_14.setTransform(92.5,268.3,0.537,0.537);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AA/CAIAAjqIgBAAIg1DqIgRAAIg1jqIgBAAIAADqIgZAAIAAj/IAsAAIArDBIABAAIArjBIAsAAIAAD/g");
	this.shape_15.setTransform(82.4,268.3,0.537,0.537);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAwCAIgPhMIhBAAIgPBMIgcAAIA5j/IAlAAIA5D/gAgcAdIA5AAIgdiJIAAAAg");
	this.shape_16.setTransform(72.5,268.3,0.537,0.537);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("Ag/CAIAAj/IA8AAQAeAAATATQATATAAAgQAAAggTATQgTASgeAAIggAAIAAB0gAgjgKIAdAAQAqAAABgvQgBgvgqAAIgdAAg");
	this.shape_17.setTransform(65.1,268.3,0.537,0.537);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AA/CAIAAjqIgBAAIg1DqIgRAAIg1jqIgBAAIAADqIgaAAIAAj/IAsAAIAsDBIABAAIAsjBIAsAAIAAD/g");
	this.shape_18.setTransform(55,268.3,0.537,0.537);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AAwCAIgPhMIhBAAIgPBMIgcAAIA5j/IAlAAIA5D/gAgcAdIA5AAIgdiJIAAAAg");
	this.shape_19.setTransform(45.1,268.3,0.537,0.537);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgzBmQgUggAAhGQAAhFAUggQASgeAkAAQA7AAAGBRIgbAAQgFg5ghAAQgYAAgLAYQgLAZAAA6QAAA7ALAZQALAYAYAAQAUAAAKgOQALgQAAgjIAcAAQgBArgSAXQgSAXggAAQgkAAgSgeg");
	this.shape_20.setTransform(36.4,268.3,0.537,0.537);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgjBHIAdhIIgaAAIAAhFIBEAAIAABFIgnBIg");
	this.shape_21.setTransform(24.9,248.8,0.537,0.537);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AhOC5QgcghgBg2IAqAAQABAmASAWQASAVAgAAQAdAAARgSQARgSAAgiQAAgggbgbQgNgOgsggQgqgcgRgVQgbghAAgoQAAgtAdgbQAcgbAuAAQAtAAAcAeQAcAeACA3IgqAAQgGhMg6AAQgaAAgQAQQgQAPAAAZQAAAfAaAaQAMAMAuAgQBVA6AABJQAAAzgcAdQgdAcgzAAQgxAAgdghg");
	this.shape_22.setTransform(189.1,237.3,0.537,0.537);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("ABPDUIgZh+IhrAAIgZB+IguAAIBdmnIA/AAIBdGngAgvAwIBfAAIgvjjIgBAAg");
	this.shape_23.setTransform(175.6,237.3,0.537,0.537);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("ABADUIiClwIgBAAIAAFwIguAAIAAmnIBHAAIBtE4IABAAIAAk4IAuAAIAAGng");
	this.shape_24.setTransform(160.9,237.3,0.537,0.537);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("ABPDUIgZh+IhrAAIgZB+IguAAIBdmnIA/AAIBdGngAgvAwIBfAAIgvjjIgBAAg");
	this.shape_25.setTransform(146.2,237.3,0.537,0.537);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("ABoDUIAAmEIgBAAIhYGEIgdAAIhYmEIgBAAIAAGEIgrAAIAAmnIBJAAIBJFAIABAAIBJlAIBJAAIAAGng");
	this.shape_26.setTransform(129.8,237.3,0.537,0.537);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AhjDUIAAmnIDAAAIAAAnIiSAAIAACQIBsAAIAAAmIhsAAIAACjICZAAIAAAng");
	this.shape_27.setTransform(114.2,237.3,0.537,0.537);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AhOC5QgcghgBg2IAqAAQABAmASAWQASAVAgAAQAdAAARgSQARgSAAgiQAAgggagbQgOgOgsggQgpgcgSgVQgaghAAgoQAAgtAcgbQAcgbAuAAQAtAAAcAeQAcAeADA3IgrAAQgGhMg6AAQgaAAgQAQQgQAPAAAZQAAAfAaAaQAMAMAuAgQBVA6AABJQAAAzgcAdQgcAcg0AAQgwAAgeghg");
	this.shape_28.setTransform(100.4,237.3,0.537,0.537);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AhHDBQgdgYAAgyIAAghIBBAAIAAAjQAAARAJAKQAJAKAPAAQAQAAAJgMQAKgMAAgcIAAhhQAAgSgKgKQgIgJgOAAQgZAAgMAfIg5AAQAFiCAAhXICwAAIgCA8IhyAAIgEBcIABABQANgQANgFQALgEASAAQApAAATAdQARAcAAA2IAAA6QAABEgWAgQgYAgg0AAQgvAAgbgWg");
	this.shape_29.setTransform(80.8,237.4,0.537,0.537);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AgVDUIAAi0IhjjzIAxAAIBIC6IBHi6IAxAAIhiDzIAAC0g");
	this.shape_30.setTransform(61,237.3,0.537,0.537);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AhkBzIAAgaIBBAAIAAAdQAAArAiAAQAhAAAAgyIAAghQAAgigOgNQgOgNghAAIAAg4QAgAAANgOQANgOAAglQAAgegHgNQgGgNgQAAQgQAAgIAJQgIAKgBAYIAAASIhBAAIAAgUQAAgsAagbQAbgcAtAAQAtAAAaAhQAYAeAAAuQAAAngJAUQgKAYgbAOQAfAQALAXQALAVgBAsQAABAgaAfQgZAeg2AAQhgAAAAhng");
	this.shape_31.setTransform(41.1,237.3,0.537,0.537);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AgDDXIAAlPIg6AAIAAgnQA5gdAdgaIAlAAIAAGtg");
	this.shape_32.setTransform(15.2,237.1,0.537,0.537);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("ApMJCIDJv3IgQPpIC+yuIApN1IAOGRICe3/ICfX/IAy0LIDDS3IABAAIgRvtIDJP3IpNEyg");
	this.shape_33.setTransform(103.1,52.4,0.537,0.537);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AU7J/QknAAiAhsQiniMAAl1QAAl7CriXQCQh+FGAAQD2AACMAQQBGAHAVAIIgZGGIiqAAIgYi8QhggLhcAAQg9AAgaAEQg7AIgqAfQh2BWAAEIQAAEGBIBpQAnA4BAAIQApAGCxgDIAAj8IicgrIAAikIHVAAIAZKvgAB5JoIAYi+IBhgRIg6prIkKM6ImEAAIkcs8Ig8JtIBgARIAZC+InrAAIAZi+IBggRIBXs4IhggRIgYi9IJXAAIENMGID8sFIJ+AAIgYC9IhgARIBLM3IBhARIAYC+gA9cJoIAYi+IBggRIAAs3IhggRIgYi9IJpAAIgZC9IhgARIAAM3IBgARIAZC+g");
	this.shape_34.setTransform(103.2,146.5,0.537,0.537);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AhZBpQgkgmAAhDQAAhBAkgmQAkgnA7AAQA2ABAhAkIAAgfIAeAAIAABhIggAAQgCgjgWgTQgWgVgjAAQgsABgaAeQgaAeAAAzQAAA3AaAeQAaAeAtABQA/AAANhGIAnAAQgFAwgeAZQgeAag0AAQg+AAgkgmg");
	this.shape_35.setTransform(70.2,199.7,0.537,0.537);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AAtCJIAAgcIAnAAIgXg9Ih7AAIgZA9IAoAAIAAAcIhrAAIAAgcIAeAAIBpj1IApAAIBnD1IAeAAIAAAcgAAxAUIgxh1IgyB1IBjAAg");
	this.shape_36.setTransform(85.7,199.7,0.537,0.537);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AiECJIAAgcIAmAAIAAjYIgmAAIAAgdIB6AAQBEAAAlAkQAmAjAABBQAABCgmAkQglAjhEAAgAg5BtIAvAAQAwAAAcgdQAcgdAAgzQAAgzgcgcQgcgcgwAAIgvAAg");
	this.shape_37.setTransform(102.4,199.7,0.537,0.537);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AAtCJIAAgcIAnAAIgXg9Ih7AAIgZA9IAoAAIAAAcIhrAAIAAgcIAeAAIBpj1IApAAIBnD1IAeAAIAAAcgAAxAUIgxh1IgyB1IBjAAg");
	this.shape_38.setTransform(55.5,199.7,0.537,0.537);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AhBCJIAAgcIAuAAIAAhXIhaiBIgWAAIAAgdIBoAAIAAAdIgnAAIBDBiIBEhiIgnAAIAAgdIBmAAIAAAdIgXAAIhcCCIAABWIAtAAIAAAcg");
	this.shape_39.setTransform(152,199.7,0.537,0.537);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("ABECJIAAgcIAlAAIAAjYIgCAAIhZD0IgfAAIhXj0IgBAAIAADYIAjAAIAAAcIhsAAIAAgcIAjAAIAAjYIgjAAIAAgdIBkAAIBODhIBPjhIBkAAIAAAdIglAAIAADYIAlAAIAAAcg");
	this.shape_40.setTransform(134.1,199.7,0.537,0.537);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AhzCJIAAgcIAmAAIAAjYIgmAAIAAgdIDnAAIAABTIgdAAIAAg2Ih/AAIAABcIA9AAIAAgpIAdAAIAABsIgdAAIAAgoIg9AAIAABhIB/AAIAAg6IAdAAIAABWg");
	this.shape_41.setTransform(116.5,199.7,0.537,0.537);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logoartwork, new cjs.Rectangle(2,5,202.3,270.4), null);


(lib.ctabgtint = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#8FA124").s().p("A4/FeIAAq7MAx/AAAIAAK7g");
	this.shape.setTransform(160,35);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ctabgtint, new cjs.Rectangle(0,0,320,70), null);


(lib.ctabg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#BFD730").s().p("A4/FeIAAq7MAx/AAAIAAK7g");
	this.shape.setTransform(160,35);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ctabg, new cjs.Rectangle(0,0,320,70), null);


(lib.ctaarrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#002F53").s().p("AhIC0ICQiQIkZAAIAAhHIEZAAIiQiQIBmAAIC0CzIi0C0g");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ctaarrow, new cjs.Rectangle(-21,-17.9,42.1,36), null);


(lib.clickthrough = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(150,125);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.imgathlete1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.img_athlete();
	this.instance.parent = this;
	this.instance.setTransform(0,261,1.33,1.33);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.imgathlete1, new cjs.Rectangle(0,261,319.2,936.3), null);


(lib.shape = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.shape_0();
	this.instance.parent = this;
	this.instance.setTransform(256.4,302.9,1,1,0,0,0,256.4,302.9);
	this.instance.alpha = 0.398;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.shape, new cjs.Rectangle(0,0,513,605.9), null);


(lib.ClipGroup = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
	mask.setTransform(337,300);

	// Layer 3
	this.instance = new lib.shape();
	this.instance.parent = this;
	this.instance.setTransform(256.4,364,1,1,0,0,0,256.4,302.9);
	this.instance.alpha = 0.398;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#002D54","#006FBA"],[0.514,1],2.2,-93.9,2.2,222.1).s().p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
	this.shape.setTransform(337,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup, new cjs.Rectangle(257,0,160,600), null);


(lib.footer = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Artwork
	this.instance = new lib.logoartwork();
	this.instance.parent = this;
	this.instance.setTransform(58.6,42,1.004,1.004);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// black
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("A4/cIMAAAg4PMAx/AAAMAAAA4Pg");
	this.shape.setTransform(160,180);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.footer, new cjs.Rectangle(0,0,320,360), null);


(lib.ctalabelsignup = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// FIND OUT MORE
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#112B53").s().p("AgyAjIAmhFIA/AAIg9BFg");
	this.shape.setTransform(66.6,-3.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#112B53").s().p("AhSCtIAAlZICeAAIAAA0IhiAAIAABZIBLAAIAAAzIhLAAIAABmIBpAAIAAAzg");
	this.shape_1.setTransform(251.6,21.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#112B53").s().p("AgdCtIAAklIg5AAIAAg0ICtAAIAAA0Ig5AAIAAElg");
	this.shape_2.setTransform(231,21.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#112B53").s().p("AhSCtIAAlZICeAAIAAA0IhjAAIAABZIBMAAIAAAzIhMAAIAABmIBqAAIAAAzg");
	this.shape_3.setTransform(211.6,21.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#112B53").s().p("AhdCtIAAlZIBYAAQBcAAAABcQAAAYgKATQgLAVgUAIQAvAUAAA9QAAAugUAaQgZAcgvAAgAghB8IAZAAQAWAAALgNQAJgNAAgbQAAgbgLgNQgMgNgZAAIgTAAgAghgeIAVAAQARAAALgLQAMgMAAgVQgBgxglAAIgXAAg");
	this.shape_4.setTransform(188.7,21.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#112B53").s().p("AgdCtIAAlZIA7AAIAAFZg");
	this.shape_5.setTransform(169.7,21.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#112B53").s().p("AAkCtIgqiPQgKABgUAAIAACOIg8AAIAAlZIBUAAQAyAAAYAXQAaAZAAA2QAABEgqASIAzCdgAgkgRIAVAAQAYAAAJgLQAKgLAAgfQAAgegKgMQgJgLgYAAIgVAAg");
	this.shape_6.setTransform(151.6,21.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#112B53").s().p("AhCCYQgXgYAAgnIAAiyQAAgmAXgYQAYgaArAAQArAAAYAcQAWAaAAApIAAAZIg8AAIAAgaQAAgWgIgLQgIgJgNgBQgQAAgHAKQgHAJAAAUIAACuQAAAVAHAIQAHAKAQAAQAQAAAHgJQAGgJAAgRIAAgpIA8AAIAAAnQAAAngWAYQgYAagrAAQgrAAgYgag");
	this.shape_7.setTransform(126.9,21.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#112B53").s().p("AhCCWQgXgbgCgpIA5gIQACAZAJAOQAKANANAAQAQAAAJgIQAKgJAAgOQAAgXgTgWQgIgJghgcQg8gyAAg2QAAgpAYgXQAYgWArAAQAkAAAWAXQAUAXAFAmIg5AGQgBgUgLgLQgIgHgMgBQgcABAAAhQAAAUATAVQAGAHAiAfQA9AzAAAzQAAAqgaAYQgaAXgpAAQgoAAgZgcg");
	this.shape_8.setTransform(104.3,21.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#112B53").s().p("AAnCtIhKjXIgBAAIAADXIg2AAIAAlZIA3AAIBHDFIABAAIAAjFIA2AAIAAFZg");
	this.shape_9.setTransform(81.8,21.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#112B53").s().p("AgdCtIAAlZIA7AAIAAFZg");
	this.shape_10.setTransform(63.1,21.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer 1
	this.arrow = new lib.ctaarrow();
	this.arrow.parent = this;
	this.arrow.setTransform(21.1,21.1,1,1,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

}).prototype = getMCSymbolPrototype(lib.ctalabelsignup, new cjs.Rectangle(0,-6.6,259.9,45.6), null);


(lib.background = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 160x600
	this.instance = new lib.ClipGroup();
	this.instance.parent = this;
	this.instance.setTransform(-1.2,666.8,2,2,0,0,0,256.4,333.4);

	this.instance_1 = new lib.BlueGradientImage();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,2,2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.background, new cjs.Rectangle(-514,0,1025.9,1333.9), null);


(lib.ctasignupon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// label
	this.cta_label = new lib.ctalabelsignup();
	this.cta_label.parent = this;
	this.cta_label.setTransform(168.4,42,1,1,0,0,0,137.4,26);
	this.cta_label.filters = [new cjs.ColorFilter(0, 0, 0, 1, 255, 255, 255, 0)];
	this.cta_label.cache(-2,-9,264,50);

	this.timeline.addTween(cjs.Tween.get(this.cta_label).wait(1));

	// cta_bg
	this.instance = new lib.ctabgtint();
	this.instance.parent = this;
	this.instance.setTransform(300,35,1,1,0,0,0,300,35);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ctasignupon, new cjs.Rectangle(0,0,320,70), null);


(lib.ctasignupoff = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// cta_label
	this.cta_label = new lib.ctalabelsignup();
	this.cta_label.parent = this;
	this.cta_label.setTransform(168.4,42,1,1,0,0,0,137.4,26);

	this.timeline.addTween(cjs.Tween.get(this.cta_label).wait(1));

	// cta_bg
	this.cta_bg = new lib.ctabg();
	this.cta_bg.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.cta_bg).wait(1));

}).prototype = getMCSymbolPrototype(lib.ctasignupoff, new cjs.Rectangle(0,0,320,70), null);


(lib.ctasignup = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.cta_on.alpha = 0;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// cta-on
	this.cta_on = new lib.ctasignupon();
	this.cta_on.parent = this;
	this.cta_on.setTransform(300,35,1,1,0,0,0,300,35);

	this.timeline.addTween(cjs.Tween.get(this.cta_on).wait(1));

	// cta-off
	this.cta_off = new lib.ctasignupoff();
	this.cta_off.parent = this;
	this.cta_off.setTransform(300,35,1,1,0,0,0,300,35);

	this.timeline.addTween(cjs.Tween.get(this.cta_off).wait(1));

}).prototype = getMCSymbolPrototype(lib.ctasignup, new cjs.Rectangle(0,0,320,70), null);


// stage content:
(lib.index = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/**
		 * Squarewave CreateJS Template 1.1 (September 2016)
		 **/
		var root = this;
		
		var stageHeight = stage.canvas.height;
		var stageWidth = stage.canvas.width;
		
		// cta
		var ctaHeight = 70; // need to get this dynamically
		var ctaOpenY = root.cta.y;
		var ctaOffset = 6; // how many pixels of the cta should be visible behind the
		var ctaClosedY = ctaOpenY + ctaHeight - ctaOffset;
		
		
		var mainTl = new TimelineMax();
		
		/**** uncomment to use within creative ******/
		/*
		root.clickthrough.on('mouseover' , onRollOver );
		root.clickthrough.on('mouseout' , onRollOut );
		root.clickthrough.on('click' , onClick );
		*/
		
		this.onInit = function () {
			this.animate();
		}
		
		// banner animation
		this.animate = function () {
			
			mainTl.add('start', 0.2)
		
			// frame 1 animation
			.from(root.facilities, 1, {
				y: stageHeight,
				ease: Strong.easeOut
			}, 'start')
			.from(root.athlete_1, 1.2, {
				scaleX: 1.5,
				scaleY: 1.5,
				alpha: 0,
				ease: Strong.easeOut
			}, 'start')
			.from(root.text_1, 1, {
					alpha: 0,
					y: '+=100',
					ease: Strong.easeOut
				}, 'start+=0.2')
				.from(root.footer, 0.75, {
					y: stageHeight,
					ease: Strong.easeOut
				}, 'start')
				.fromTo(root.cta, 0.75, {
					y: stageHeight
				}, {
					y: ctaClosedY,
					ease: Strong.easeOut
				}, 'start')
		
			// frame 2
			.add('frame2', '+=1')
				.to(root.text_1, 0.5, {
					alpha: 0,
					ease: Strong.easeOut
				}, 'frame2')
				.from(root.text_2, 0.65, {
					alpha: 0,
					y: '+=100',
					ease: Strong.easeOut
				}, 'frame2+=0.75')
				
				// Athlete transition
				/*.to(root.athlete_1, 1.4, {
					x: '-=' + stageWidth,
					ease: Strong.easeOut
				}, 'frame2+=0.75')
				.from(root.athlete_2, 1.4, {
					x: '+=' + stageWidth,
					ease: Strong.easeOut
				}, 'frame2+=0.75')*/
				
		
			// transition to end frame 
			.add('frame3', '+=1.5')
				.to(root.text_2, 0.5, {
					alpha: 0,
					ease: Strong.easeOut
				}, 'frame3')
				.to(root.facilities, 0.5, {
				y: stageHeight,
				alpha: 0,
				ease: Strong.easeOut
			}, 'frame3')
			.to(root.athlete_1, 0.5, {
					alpha: 0,
					scaleX: 1.5,
					scaleY: 1.5,
					ease: Strong.easeIn
				}, 'frame3')
				
		
			.add('endFrame')
				.from(root.text_3, 0.65, {
					alpha: 0,
					scaleX: 0.6,
					scaleY: 0.6,
					ease: Strong.easeOut
				}, 'endFrame')
				.to(root.cta, 0.6, {
					y: ctaOpenY,
					ease: Back.easeOut.config(0.5),
					onComplete: this.ctaOpen
				}, 'endFrame+=0.6');
		}
		
		var ctaIsOpen = false;
		// only do the rollover on the cta if it's open/visible
		this.ctaOpen = function () {
			if (!ctaIsOpen) {
				ctaIsOpen = true;
			}
		}
		
		// mouse over/mouse out events
		this.onRollOverEvent = function (e) {
			// wake up creative if asleep //
			if (root.adHelper && !root.adHelper.awake) root.adHelper.wake();
		
			if (ctaIsOpen) TweenMax.to(root.cta.cta_on, 0.2, {
				alpha: 1
			});
		}
		
		this.onRollOutEvent = function (e) {
			if (ctaIsOpen) TweenMax.to(root.cta.cta_on, 0.2, {
				alpha: 0
			});
		}
		
		this.onClickEvent = function (e) {
			console.log("creative-click");
		}
		
		
		
		
		
		
		/**
		 * AD HELPER METHODS
		 *
		 * If everything is setup correctly, you can use
		 * root.adHelper.sleep() & root.adHelper.wake()
		 * to manually control AdHelper.
		 * NOTE: sleep() pauses CreateJS AND TweenLite
		 *
		 **/
		this.adHelper = null; // adhelper reference //
		this.onSlowDown = function () {
			console.log("creative-slowdown");
		}
		
		this.onSleep = function () {
			console.log("creative-sleep");
		}
		
		this.onWake = function () {
			console.log("creative-wake");
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// clickthrough
	this.clickthrough = new lib.clickthrough();
	this.clickthrough.parent = this;
	this.clickthrough.setTransform(160,599.9,1.067,4.8,0,0,0,150,125);
	new cjs.ButtonHelper(this.clickthrough, 0, 1, 2, false, new lib.clickthrough(), 3);

	this.timeline.addTween(cjs.Tween.get(this.clickthrough).wait(1));

	// footer
	this.footer = new lib.footer();
	this.footer.parent = this;
	this.footer.setTransform(0,840);

	this.timeline.addTween(cjs.Tween.get(this.footer).wait(1));

	// cta
	this.cta = new lib.ctasignup();
	this.cta.parent = this;
	this.cta.setTransform(0,770);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// text: headline 3
	this.text_3 = new lib.textheadline3();
	this.text_3.parent = this;
	this.text_3.setTransform(160,401.9,1,1,0,0,0,160,401.9);
	this.text_3.cache(-2,-2,324,1204);

	this.timeline.addTween(cjs.Tween.get(this.text_3).wait(1));

	// athlete_1
	this.athlete_1 = new lib.imgathlete1();
	this.athlete_1.parent = this;
	this.athlete_1.setTransform(160,600,1,1,0,0,0,160,600);

	this.timeline.addTween(cjs.Tween.get(this.athlete_1).wait(1));

	// text: headline 2
	this.text_2 = new lib.textheadline2();
	this.text_2.parent = this;
	this.text_2.cache(28,90,265,122);

	this.timeline.addTween(cjs.Tween.get(this.text_2).wait(1));

	// text: headline 1
	this.text_1 = new lib.textheadline1();
	this.text_1.parent = this;
	this.text_1.cache(27,85,264,129);

	this.timeline.addTween(cjs.Tween.get(this.text_1).wait(1));

	// image: facilities
	this.facilities = new lib.img_facilities_1();
	this.facilities.parent = this;
	this.facilities.setTransform(120,450,1,1,0,0,0,120,450);

	this.timeline.addTween(cjs.Tween.get(this.facilities).wait(1));

	// background
	this.bg = new lib.background();
	this.bg.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-354,599.9,1025.9,1334.1);
// library properties:
lib.properties = {
	width: 320,
	height: 1200,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/BlueGradientImage.png?1481835865438", id:"BlueGradientImage"},
		{src:"images/img_athlete.png?1481835865438", id:"img_athlete"},
		{src:"images/img_facilities.png?1481835865438", id:"img_facilities"}
	],
	preloads: []
};




})(lib = lib||{}, images = images||{}, createjs = createjs||{}, ss = ss||{}, AdobeAn = AdobeAn||{});
var lib, images, createjs, ss, AdobeAn;