(function (lib, img, cjs, ss, an) {

var p; // shortcut to reference prototypes
lib.ssMetadata = [];


// symbols:



(lib.img_athlete = function() {
	this.initialize(img.img_athlete);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,231,340);


(lib.img_facilities = function() {
	this.initialize(img.img_facilities);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,449,375);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib._25Multiply50Image = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#000000","rgba(0,0,0,0)"],[0,1],-3.4,-12.6,-3.4,26.9).s().p("A3bE7IAAp1MAu3AAAIAAJ1g");
	this.shape.setTransform(150,31.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib._25Multiply50Image, new cjs.Rectangle(0,0,300,63), null);


(lib.textheadline3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AA9ELIh0lNIgCAAIAAFNIhTAAIAAoVIBVAAIBvEwIACAAIAAkwIBTAAIAAIVg");
	this.shape.setTransform(284.8,180.2,0.914,0.914);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ah/ELIAAoVID1AAIAABQIiZAAIAACJIB1AAIAABPIh1AAIAACdICjAAIAABQg");
	this.shape_1.setTransform(253.6,180.2,0.914,0.914);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhOA1IA6hpIBjAAIhgBpg");
	this.shape_2.setTransform(367.2,146.8,0.914,0.914);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhpDqQgigkgBg9IAAkRQABg9AigkQAlgoBEAAQBFAAAlAoQAjAkgBA9IAAERQABA9gjAkQglAohFAAQhEAAglgogAgmizQgKAOAAAeIAAEOQAAAfAKAOQAMAPAaAAQAbAAALgPQAKgOAAgfIAAkOQAAgegKgOQgLgPgbAAQgaAAgMAPg");
	this.shape_3.setTransform(360,180.2,0.914,0.914);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("ABCELIgQh2IhkAAIgQB2IhYAAIBioVIBxAAIBiIVgAgkBFIBJAAIgkjlIgBAAg");
	this.shape_4.setTransform(558.7,180.2,0.914,0.914);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ah/ELIAAoVID1AAIAABQIiaAAIAACJIB2AAIAABPIh2AAIAACdICkAAIAABQg");
	this.shape_5.setTransform(528.4,180.2,0.914,0.914);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhmDnQgjgqgDg/IBXgMQADAnAPAWQAOAUAWAAQAYAAAOgNQAPgNAAgXQAAgjgdghQgNgOgygsQhehOAAhTQAAg/AmgjQAlgjBDAAQA2AAAiAlQAhAiAGA7IhXAJQgDgfgQgPQgMgNgSAAQgVAAgMAOQgMAOAAAZQAAAeAdAfQAKALA1AvQBdBQAABQQAABBgoAkQgnAkhBAAQg9AAgmgsg");
	this.shape_6.setTransform(497.9,180.2,0.914,0.914);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ah/ELIAAoVID1AAIAABQIiZAAIAACJIB1AAIAABPIh1AAIAACdICjAAIAABQg");
	this.shape_7.setTransform(456.5,180.2,0.914,0.914);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AiMELIAAoVICJAAQCQAAAAChIAADTQAAChiQAAgAgvDAIAfAAQAkAAAPgRQAOgQAAgqIAAjpQAAgqgOgQQgPgRgkAAIgfAAg");
	this.shape_8.setTransform(425.2,180.2,0.914,0.914);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AA9ELIh0lNIgCAAIAAFNIhTAAIAAoVIBWAAIBuEwIACAAIAAkwIBTAAIAAIVg");
	this.shape_9.setTransform(392.5,180.2,0.914,0.914);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AiMELIAAoVICJAAQCQAAAAChIAADTQAAChiQAAgAgwDAIAgAAQAkAAAOgRQAPgQAAgqIAAjpQAAgqgPgQQgOgRgkAAIggAAg");
	this.shape_10.setTransform(327.5,180.2,0.914,0.914);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("Ah/EMIAAoXID1AAIAABQIiZAAIAACLIB1AAIAABOIh1AAIAACeICjAAIAABQg");
	this.shape_11.setTransform(211.2,180.2,0.914,0.914);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgtEMIAAnHIhZAAIAAhQIENAAIAABQIhZAAIAAHHg");
	this.shape_12.setTransform(183.4,180.2,0.914,0.914);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgtEMIAAoXIBbAAIAAIXg");
	this.shape_13.setTransform(162.6,180.2,0.914,0.914);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AiUEMIAAoXICEAAQBWAAAnAlQAoAlAABVQAABUgoAkQgnAkhWAAIgoAAIAADcgAg4gbIAjAAQAtAAAQgRQARgRAAgvQAAgwgRgRQgQgSgtABIgjAAg");
	this.shape_14.setTransform(139.7,180.2,0.914,0.914);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("ABrEMIAAmiIgCAAIhTGiIgrAAIhTmiIgCAAIAAGiIhQAAIAAoXIB5AAIBBE4IABAAIBBk4IB5AAIAAIXg");
	this.shape_15.setTransform(103.7,180.2,0.914,0.914);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AhpDrQgjglAAg8IAAkTQAAg8AjglQAlgoBEAAQBFAAAlAoQAjAlAAA8IAAETQAAA8gjAlQglAohFAAQhEAAglgogAgmizQgKANAAAfIAAEOQAAAfAKAOQAMAPAaAAQAbAAALgPQALgOAAgfIAAkOQAAgfgLgNQgLgPgbAAQgaAAgMAPg");
	this.shape_16.setTransform(68.6,180.2,0.914,0.914);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AhnDrQgjglAAg8IAAkTQAAg8AjglQAlgoBEAAQBCAAAlAsQAhAnAABAIAAAnIhbAAIAAgqQgBgggNgRQgMgPgTAAQgaAAgLAPQgLANAAAfIAAEOQAAAfALAOQALAPAaAAQAYAAALgOQAKgNAAgbIAAhBIBbAAIAAA+QAAA8ghAlQglAohCAAQhEAAglgog");
	this.shape_17.setTransform(37.6,180.2,0.914,0.914);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AhmDmQgjgogDhAIBXgMQADAnAPAVQAOAVAWAAQAYAAAPgNQAOgNAAgYQAAgigdghQgMgOgzgsQhdhNAAhTQAAg/AlgkQAlgiBDAAQA2AAAiAlQAhAiAGA6IhXAKQgDgggPgPQgNgNgSAAQgVAAgMAPQgMANAAAZQAAAeAdAgQAKALA1AuQBdBQAABPQAABBgoAlQgnAjhBAAQg9AAgmgsg");
	this.shape_18.setTransform(561.2,114.1,0.914,0.914);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AhpDqQgigkAAg9IAAkRQAAg9AigkQAlgoBEAAQBFAAAlAoQAiAkAAA9IAAERQAAA9giAkQglAohFAAQhEAAglgogAglizQgLAOAAAfIAAENQAAAfALAOQALAPAaAAQAbAAALgPQALgOAAgfIAAkNQAAgfgLgOQgLgPgbAAQgaAAgLAPg");
	this.shape_19.setTransform(531.1,114.1,0.914,0.914);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AA3ELIg/jdQgRACgfAAIAADbIhcAAIAAoVICBAAQBOABAlAjQAnAmAABUQAABphAAcIBNDygAg4gaIAgAAQAlgBAPgRQAQgSAAguQAAgwgQgRQgPgSglABIggAAg");
	this.shape_20.setTransform(500.7,114.1,0.914,0.914);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgtELIAAnFIhYAAIAAhQIELAAIAABQIhYAAIAAHFg");
	this.shape_21.setTransform(470.9,114.1,0.914,0.914);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AhpDqQgigkAAg9IAAkRQAAg9AigkQAlgoBEAAQBFAAAlAoQAiAkAAA9IAAERQAAA9giAkQglAohFAAQhEAAglgogAgmizQgKAOAAAfIAAENQAAAfAKAOQAMAPAaAAQAaAAAMgPQALgOAAgfIAAkNQAAgfgLgOQgMgPgaAAQgaAAgMAPg");
	this.shape_22.setTransform(442.1,114.1,0.914,0.914);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AhmDmQgjgogDhAIBXgMQADAnAPAVQAOAVAWAAQAYAAAOgNQAPgNAAgYQAAgigdghQgNgOgygsQhdhNAAhTQAAg/AlgkQAlgiBDAAQA2AAAiAlQAgAiAHA6IhYAKQgCgggQgPQgMgNgSAAQgVAAgMAPQgMANAAAZQAAAeAdAgQAKALA1AuQBdBQAABPQAABBgoAlQgnAjhBAAQg9AAgmgsg");
	this.shape_23.setTransform(411.8,114.1,0.914,0.914);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AhpDqQgigkAAg9IAAkRQAAg9AigkQAlgoBEAAQBFAAAlAoQAiAkAAA9IAAERQAAA9giAkQglAohFAAQhEAAglgogAglizQgLAOAAAfIAAENQAAAfALAOQALAPAaAAQAbAAALgPQALgOAAgfIAAkNQAAgfgLgOQgLgPgbAAQgaAAgLAPg");
	this.shape_24.setTransform(381.7,114.1,0.914,0.914);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AA8ELIhzlMIgCAAIAAFMIhSAAIAAoVIBUAAIBvEwIACAAIAAkwIBSAAIAAIVg");
	this.shape_25.setTransform(350.5,114.1,0.914,0.914);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AA9ELIh0lMIgCAAIAAFMIhSAAIAAoVIBVAAIBuEwIACAAIAAkwIBSAAIAAIVg");
	this.shape_26.setTransform(304.5,114.1,0.914,0.914);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AhpDqQgigkAAg9IAAkRQAAg9AigkQAlgoBEAAQBFAAAlAoQAiAkAAA9IAAERQAAA9giAkQglAohFAAQhEAAglgogAglizQgLAOAAAfIAAENQAAAfALAOQALAPAaAAQAbAAALgPQALgOAAgfIAAkNQAAgfgLgOQgLgPgbAAQgaAAgLAPg");
	this.shape_27.setTransform(273.4,114.1,0.914,0.914);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AhnDqQgigkAAg9IAAkRQAAg9AigkQAlgoBEAAQBBAAAlArQAiAoAAA/IAAAnIhbAAIAAgpQAAgggOgRQgLgQgUAAQgaAAgLAPQgLAOAAAfIAAENQAAAfALAOQALAPAaAAQAYAAALgOQAKgNAAgbIAAhBIBbAAIAAA9QAAA8giAlQgkAohCAAQhEAAglgog");
	this.shape_28.setTransform(242.3,114.1,0.914,0.914);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("ABCELIgQh3IhkAAIgPB3IhZAAIBioVIBxAAIBiIVgAgkBFIBJAAIgkjlIgBAAg");
	this.shape_29.setTransform(198.4,114.1,0.914,0.914);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AiTELIAAoVICDAAQBVABAnAjQApAmAABUQAABUgpAkQgnAkhVAAIgoAAIAADbgAg4gaIAkAAQArgBASgRQAQgRAAgvQAAgwgQgRQgSgSgrABIgkAAg");
	this.shape_30.setTransform(170.5,114.1,0.914,0.914);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("ABqELIAAmgIgBAAIhTGgIgrAAIhTmgIgCAAIAAGgIhPAAIAAoVIB4AAIBBE3IAAAAIBCk3IB4AAIAAIVg");
	this.shape_31.setTransform(134.4,114.1,0.914,0.914);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("ABDELIgRh3IhjAAIgQB3IhZAAIBioVIBxAAIBiIVgAgkBFIBJAAIgkjlIgBAAg");
	this.shape_32.setTransform(99.5,114.1,0.914,0.914);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AhnDqQgigkAAg9IAAkRQAAg9AigkQAlgoBEAAQBCAAAlArQAhAoAAA/IAAAnIhcAAIAAgpQABgggNgRQgNgQgTAAQgaAAgLAPQgKAOAAAfIAAENQAAAfAKAOQALAPAaAAQAYAAALgOQAJgNAAgbIAAhBIBcAAIAAA9QAAA9ghAkQglAohCAAQhEAAglgog");
	this.shape_33.setTransform(69.6,114.1,0.914,0.914);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("ABCELIgQh3IhjAAIgRB3IhYAAIBioVIBxAAIBiIVgAgkBFIBJAAIgkjlIgBAAg");
	this.shape_34.setTransform(39.8,114.1,0.914,0.914);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.textheadline3, new cjs.Rectangle(25,89,549.2,116.3), null);


(lib.textheadline2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 4
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhtBKIBSiTICJAAIiGCTg");
	this.shape.setTransform(126.6,50.5,0.579,0.579);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AimA/QAXh4BTAAQAQAAASAGQAJADAWAKIAeAOQASAHAOAAQAXAAAKgLQAJgLABgXIA5AAQgYB4hSAAQgZAAgogVQgUgKgLgDQgQgGgPAAQgXAAgKALQgJALgBAXg");
	this.shape_1.setTransform(151.3,51.1,0.579,0.579);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("ABUFzIihnPIgCAAIAAHPIhzAAIAArlIB2AAICaGnIACAAIAAmnIBzAAIAALlg");
	this.shape_2.setTransform(151.5,81,0.579,0.579);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AixFzIAArlIFUAAIAABvIjUAAIAAC/ICjAAIAABuIijAAIAADaIDjAAIAABvg");
	this.shape_3.setTransform(124.7,81,0.579,0.579);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("ABcFzIgWilIiLAAIgWClIh8AAICJrlICdAAICJLlgAgyBfIBlAAIgyk9IgBAAg");
	this.shape_4.setTransform(354.7,81,0.579,0.579);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AijFzIAArlIB/AAIAAJ2IDIAAIAABvg");
	this.shape_5.setTransform(329.5,81,0.579,0.579);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AixFzIAArlIFUAAIAABvIjVAAIAAC/ICkAAIAABuIikAAIAADaIDkAAIAABvg");
	this.shape_6.setTransform(294.5,81,0.579,0.579);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AjCFzIAArlIC9AAQDIAAAADgIAAElQAADgjIAAgAhDEKIAsAAQAyAAAVgXQAUgWAAg7IAAlDQAAg7gUgXQgVgWgyAAIgsAAg");
	this.shape_7.setTransform(267,81,0.579,0.579);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AiwFzIAArlIFTAAIAABvIjUAAIAAC/ICjAAIAABuIijAAIAADaIDiAAIAABvg");
	this.shape_8.setTransform(228.7,81,0.579,0.579);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ag/FzIAAp2Ih7AAIAAhvIF1AAIAABvIh8AAIAAJ2g");
	this.shape_9.setTransform(203,81,0.579,0.579);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("ABcFzIgWilIiLAAIgWClIh8AAICJrlICdAAICJLlgAgyBfIBlAAIgyk9IgBAAg");
	this.shape_10.setTransform(179.9,81,0.579,0.579);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AiOFFQg0g0AAheIAAoqIB/AAIAAIvQAABRBDAAQBEAAAAhRIAAovIB/AAIAAIqQAABeg0A0QgzAzhcAAQhbAAgzgzg");
	this.shape_11.setTransform(96.9,81.2,0.579,0.579);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AjCFzIAArlIC9AAQDIAAAADgIAAElQAADgjIAAgAhDEKIAsAAQAzAAATgXQAVgXAAg6IAAlDQAAg7gVgXQgTgWgzAAIgsAAg");
	this.shape_12.setTransform(68.4,81,0.579,0.579);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("ABdFzIgXilIiLAAIgWClIh8AAICJrlICdAAICJLlgAgyBfIBlAAIgyk9IgBAAg");
	this.shape_13.setTransform(40,81,0.579,0.579);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AhtBKIBSiTICJAAIiGCTg");
	this.shape_14.setTransform(126.6,50.5,0.579,0.579);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AimA/QAXh4BTAAQAQAAASAGQAJADAWAKIAeAOQASAHAOAAQAXAAAKgLQAJgLABgXIA5AAQgYB4hSAAQgZAAgogVQgUgKgLgDQgQgGgPAAQgXAAgKALQgJALgBAXg");
	this.shape_15.setTransform(151.3,51.1,0.579,0.579);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AixFzIAArlIFUAAIAABvIjUAAIAAC/ICjAAIAABuIijAAIAADaIDjAAIAABvg");
	this.shape_16.setTransform(124.7,81,0.579,0.579);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("ABcFzIgWilIiLAAIgWClIh8AAICJrlICdAAICJLlgAgyBfIBlAAIgyk9IgBAAg");
	this.shape_17.setTransform(354.7,81,0.579,0.579);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AijFzIAArlIB/AAIAAJ2IDIAAIAABvg");
	this.shape_18.setTransform(329.5,81,0.579,0.579);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AixFzIAArlIFUAAIAABvIjVAAIAAC/ICkAAIAABuIikAAIAADaIDkAAIAABvg");
	this.shape_19.setTransform(294.5,81,0.579,0.579);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AjCFzIAArlIC9AAQDIAAAADgIAAElQAADgjIAAgAhDEKIAsAAQAyAAAVgXQAUgWAAg7IAAlDQAAg7gUgXQgVgWgyAAIgsAAg");
	this.shape_20.setTransform(267,81,0.579,0.579);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AiwFzIAArlIFTAAIAABvIjUAAIAAC/ICjAAIAABuIijAAIAADaIDiAAIAABvg");
	this.shape_21.setTransform(228.7,81,0.579,0.579);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("Ag/FzIAAp2Ih7AAIAAhvIF1AAIAABvIh8AAIAAJ2g");
	this.shape_22.setTransform(203,81,0.579,0.579);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("ABcFzIgWilIiLAAIgWClIh8AAICJrlICdAAICJLlgAgyBfIBlAAIgyk9IgBAAg");
	this.shape_23.setTransform(179.9,81,0.579,0.579);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AiOFFQg0g0AAheIAAoqIB/AAIAAIvQAABRBDAAQBEAAAAhRIAAovIB/AAIAAIqQAABeg0A0QgzAzhcAAQhbAAgzgzg");
	this.shape_24.setTransform(96.9,81.2,0.579,0.579);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AjCFzIAArlIC9AAQDIAAAADgIAAElQAADgjIAAgAhDEKIAsAAQAzAAATgXQAVgXAAg6IAAlDQAAg7gVgXQgTgWgzAAIgsAAg");
	this.shape_25.setTransform(68.4,81,0.579,0.579);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("ABdFzIgXilIiLAAIgWClIh8AAICJrlICdAAICJLlgAgyBfIBlAAIgyk9IgBAAg");
	this.shape_26.setTransform(40,81,0.579,0.579);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("ADDMNIgvlaIkmAAIgvFaIkEAAIEg4aIFMAAIEgYagAhrDJIDXAAIhqqeIgDAAg");
	this.shape_27.setTransform(348.8,156.3,0.579,0.579);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("ACPMNIAAq1IkdAAIAAK1IkMAAIAA4aIEMAAIAAJ9IEdAAIAAp9IEMAAIAAYag");
	this.shape_28.setTransform(289.1,156.3,0.579,0.579);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AkwKuQhkhsAAivIAAslQAAivBkhsQBuh1DIAAQDBAABrB/QBjB0AAC6IAAByIkNAAIAAh5QAAhdgngyQgigtg5AAQhOAAghArQgfAoAABaIAAMXQAABbAfAoQAhAqBOAAQBHAAAfgoQAcgmAAhQIAAi8IENAAIAAC0QAACuhjBtQhrB1jBAAQjIAAhuh1g");
	this.shape_29.setTransform(228.9,156.3,0.579,0.579);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("ACxMNIlVvPIgEAAIAAPPIjyAAIAA4aID4AAIFGN+IAFAAIAAt+IDyAAIAAYag");
	this.shape_30.setTransform(168.9,156.3,0.579,0.579);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("ADDMNIgwlaIklAAIgwFaIkEAAIEg4aIFNAAIEgYagAhrDJIDXAAIhqqeIgDAAg");
	this.shape_31.setTransform(109.1,156.3,0.579,0.579);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AkwKuQhkhsAAivIAAslQAAivBkhsQBuh1DIAAQDBAABsB/QBiB0AAC6IAAByIkMAAIAAh5QAAhdgogyQgigtg5AAQhOAAggArQggAnAABbIAAMXQAABbAgAoQAgAqBOAAQBHAAAfgoQAdgmAAhQIAAi8IEMAAIAAC0QAACuhiBtQhrB1jCAAQjIAAhuh1g");
	this.shape_32.setTransform(51,156.3,0.579,0.579);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.textheadline2, new cjs.Rectangle(27.5,46.2,347.7,156.6), null);


(lib.textheadline1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ah+BWIBeirICfAAIibCrg");
	this.shape.setTransform(142,49.9,0.564,0.564);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AjABJQAbiLBfAAQATAAAVAHQANAEAXAMIAjAPQAUAIAQAAQAaAAAMgNQALgMABgbIBCAAQgbCLhfAAQgTAAgVgHQgNgFgXgMQgsgWgbAAQgbAAgMANQgKAMgBAbg");
	this.shape_1.setTransform(169.8,50.6,0.564,0.564);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("ABhGsIi6oWIgCAAIAAIWIiFAAIAAtXICIAAICyHpIACAAIAAnpICFAAIAANXg");
	this.shape_2.setTransform(170.1,84.1,0.564,0.564);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ak4KwQhkhrAAixIAAsnQAAixBkhrQBuh2DKAAQDKAABuB2QBlBrAACxIAAMnQAACxhlBrQhuB2jKAAQjKAAhuh2gAhvoQQgfAoAABbIAAMbQAABaAfAoQAhArBOAAQBQAAAggrQAggoAAhaIAAsbQAAhbgggoQgggrhQAAQhOAAghArg");
	this.shape_3.setTransform(346,162.2,0.564,0.564);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("ACyMQIlWvTIgFAAIAAPTIjzAAIAA4fID6AAIFHOAIAFAAIAAuAIDzAAIAAYfg");
	this.shape_4.setTransform(287,162.2,0.564,0.564);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("ADEMQIgwlbIkmAAIgxFbIkFAAIEh4fIFPAAIEhYfgAhrDKIDYAAIhrqgIgDAAg");
	this.shape_5.setTransform(228.6,162.2,0.564,0.564);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("ACjMQIi+qJQg5AGhTABIAAKCIkNAAIAA4fIF6AAQDoAABtBqQBzBuAAD2QAACtg9BoQguBRhTAlIDlLGgAinhQIBgAAQBuABAsgzQAtg0AAiLQAAiKgtg1QgsgyhuAAIhgAAg");
	this.shape_6.setTransform(170.1,162.2,0.564,0.564);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Al3MQIAA4fILQAAIAADrInCAAIAAGUIFaAAIAADpIlaAAIAAHNIHhAAIAADqg");
	this.shape_7.setTransform(113.4,162.2,0.564,0.564);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AiGMQIlI4fIEJAAIDERAIADAAIDExAIEJAAIlIYfg");
	this.shape_8.setTransform(56.8,162.2,0.564,0.564);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ai8GsIAAtXICTAAIAALXIDmAAIAACAg");
	this.shape_9.setTransform(358.7,84.1,0.564,0.564);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AjMGsIAAtXIGIAAIAACAIj1AAIAADdIC8AAIAAB/Ii8AAIAAD7IEGAAIAACAg");
	this.shape_10.setTransform(330.7,84.1,0.564,0.564);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AjgGsIAAtXIDaAAQDnAAAAEDIAAFRQAAEDjnAAgAhNEzIAzAAQA5AAAYgaQAXgaAAhEIAAl1QAAhEgXgaQgYgag5AAIgzAAg");
	this.shape_11.setTransform(299.8,84.1,0.564,0.564);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AjMGsIAAtXIGIAAIAACAIj1AAIAADdIC9AAIAAB/Ii9AAIAAD7IEGAAIAACAg");
	this.shape_12.setTransform(256.7,84.1,0.564,0.564);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AhJGsIAArXIiOAAIAAiAIGuAAIAACAIiOAAIAALXg");
	this.shape_13.setTransform(227.9,84.1,0.564,0.564);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("ABqGsIgai+IifAAIgaC+IiPAAICetXIC1AAICeNXgAg6BuIB1AAIg6luIgBAAg");
	this.shape_14.setTransform(201.9,84.1,0.564,0.564);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AjMGsIAAtXIGIAAIAACAIj1AAIAADdIC9AAIAAB/Ii9AAIAAD7IEGAAIAACAg");
	this.shape_15.setTransform(139.9,84.1,0.564,0.564);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AikF3Qg8g7AAhuIAAp/ICTAAIAAKFQAABeBNAAQBOAAAAheIAAqFICTAAIAAJ/QAABug8A7Qg7A7hqAAQhpAAg7g7g");
	this.shape_16.setTransform(108.7,84.5,0.564,0.564);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AjgGsIAAtXIDaAAQDnAAAAEDIAAFRQAAEDjnAAgAhNEzIAzAAQA6AAAXgaQAXgaAAhEIAAl1QAAhEgXgaQgXgag6AAIgzAAg");
	this.shape_17.setTransform(76.6,84.1,0.564,0.564);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("ABqGsIgai+IigAAIgaC+IiOAAICetXIC1AAICeNXgAg6BuIB1AAIg6luIgBAAg");
	this.shape_18.setTransform(44.7,84.1,0.564,0.564);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.textheadline1, new cjs.Rectangle(30.7,45.1,338.7,162.7), null);


(lib.img_facilities_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.img_facilities();
	this.instance.parent = this;
	this.instance.setTransform(0,0,1.336,1.336);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.img_facilities_1, new cjs.Rectangle(0,0,600,501.1), null);


(lib.logoartwork = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ag6AAQAAhrA6AAQA7AAAABrQAABsg7AAQg6AAAAhsgAgZhGQgKAVAAAxQAAAyAKAVQAJASAQAAQAlAAAAhZQAAhYglAAQgQAAgJASg");
	this.shape.setTransform(477.9,81.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgKBpIgxjRIAXAAIAkClIAAAAIAlilIAXAAIgyDRg");
	this.shape_1.setTransform(464.2,81.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgKBpIAAjRIAVAAIAADRg");
	this.shape_2.setTransform(454.6,81.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgKBpIAAi+IgsAAIAAgTIBsAAIAAATIgrAAIAAC+g");
	this.shape_3.setTransform(445.7,81.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAfBpIghhkIgdACIAABiIgXAAIAAjRIAzAAQAYAAAQAOQAQAPAAAZQAAAogiALIAkBogAgfgMIATAAQAXAAAKgJQAJgJAAgSQAAgTgJgIQgKgKgXAAIgTAAg");
	this.shape_4.setTransform(433.4,81.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag6AAQAAhrA6AAQA7AAAABrQAABsg7AAQg6AAAAhsgAgZhGQgKAVAAAxQAAAyAKAVQAJASAQAAQARAAAJgSQALgVAAgyQAAgxgLgVQgJgSgRAAQgQAAgJASg");
	this.shape_5.setTransform(418.7,81.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgzBpIAAjRIAxAAQAYAAAQAQQAOAQAAAaQAAAagOAPQgQAPgYAAIgbAAIAABfgAgdgIIAYAAQAjAAAAgmQAAgngjAAIgYAAg");
	this.shape_6.setTransform(405.5,81.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgxBpIAAjRIBfAAIAAATIhIAAIAABIIA1AAIAAASIg1AAIAABRIBMAAIAAATg");
	this.shape_7.setTransform(392.6,81.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("Ag2BpIAAjRIAnAAQAjAAAQAXQATAYAAA5QAAA5gTAZQgQAXgjAAgAgfBWIAMAAQAaAAAMgQQAOgUgBgyQABgygOgTQgMgQgaAAIgMAAg");
	this.shape_8.setTransform(378.6,81.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ag6AAQAAhrA6AAQA7AAAABrQAABsg7AAQg6AAAAhsgAgZhGQgKAVAAAxQAAAyAKAVQAJASAQAAQAlAAAAhZQAAhYglAAQgQAAgJASg");
	this.shape_9.setTransform(357.4,81.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgLBpIAAi+IgqAAIAAgTIBrAAIAAATIgrAAIAAC+g");
	this.shape_10.setTransform(344.5,81.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAgBpIhAi2IgBAAIAAC2IgWAAIAAjRIAjAAIA1CaIABAAIAAiaIAWAAIAADRg");
	this.shape_11.setTransform(331.6,81.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgxBpIAAjRIBfAAIAAATIhIAAIAABIIA1AAIAAASIg1AAIAABRIBMAAIAAATg");
	this.shape_12.setTransform(318.3,81.5);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AA0BpIAAi/IgBAAIgsC/IgOAAIgri/IgBAAIAAC/IgVAAIAAjRIAkAAIAkCeIABAAIAjieIAkAAIAADRg");
	this.shape_13.setTransform(302.6,81.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAnBpIgMg+Ig1AAIgMA+IgXAAIAujRIAfAAIAuDRgAgWAXIAuAAIgYhvIAAAAg");
	this.shape_14.setTransform(287.2,81.5);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgzBpIAAjRIAwAAQAZAAAQAQQAPAQgBAaQABAagPAPQgQAPgZAAIgaAAIAABfgAgdgIIAYAAQAjAAAAgmQAAgngjAAIgYAAg");
	this.shape_15.setTransform(275.3,81.5);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AA0BpIAAi/IgBAAIgsC/IgNAAIgsi/IgBAAIAAC/IgUAAIAAjRIAkAAIAjCeIABAAIAjieIAkAAIAADRg");
	this.shape_16.setTransform(259.5,81.5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AAnBpIgMg+Ig0AAIgNA+IgXAAIAujRIAfAAIAuDRgAgXAXIAuAAIgWhvIgBAAg");
	this.shape_17.setTransform(244.2,81.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("Ag6AAQAAhrA8AAQAxAAAFBCIgXAAQgEgvgbAAQgTAAgJAUQgJAVAAAvQAAAwAJAVQAJAUATAAQAhAAABg2IAXAAQgBAjgOATQgPATgbAAQg8AAAAhsg");
	this.shape_18.setTransform(230.4,81.5);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgwBpIAAjRIBeAAIAAATIhIAAIAABIIA1AAIAAASIg1AAIAABRIBMAAIAAATg");
	this.shape_19.setTransform(210.8,81.5);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("Ag2BpIAAjRIAnAAQAiAAARAXQATAZAAA4QAAA5gTAZQgRAXgiAAgAgfBWIAMAAQAaAAAMgQQAOgUgBgyQABgygOgTQgMgQgaAAIgMAAg");
	this.shape_20.setTransform(196.8,81.5);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgmBbQgOgQAAgbIAVAAQABApAgAAQAOAAAIgJQAJgKAAgQQAAgWgpgeQgqgdAAgfQgBgWAOgOQAPgNAWAAQAWAAAOAPQAOAPABAbIgVAAQgDgmgcAAQgNAAgIAIQgIAIAAAMQAAAVAqAdQApAcAAAkQAAAagNAOQgPAOgZAAQgYAAgOgRg");
	this.shape_21.setTransform(176.4,81.5);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AAnBpIgMg+Ig1AAIgNA+IgWAAIAujRIAeAAIAvDRgAgXAXIAuAAIgXhvIAAAAg");
	this.shape_22.setTransform(163.6,81.5);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AAgBpIhAi2IgBAAIAAC2IgWAAIAAjRIAjAAIA1CaIABAAIAAiaIAWAAIAADRg");
	this.shape_23.setTransform(149.8,81.5);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AAnBpIgMg+Ig1AAIgMA+IgXAAIAujRIAfAAIAuDRgAgXAXIAuAAIgXhvIAAAAg");
	this.shape_24.setTransform(136.1,81.5);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AAzBpIAAi/IAAAAIgsC/IgNAAIgsi/IAAAAIAAC/IgVAAIAAjRIAkAAIAjCeIABAAIAkieIAkAAIAADRg");
	this.shape_25.setTransform(120.8,81.5);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgxBpIAAjRIBfAAIAAATIhIAAIAABIIA1AAIAAASIg1AAIAABRIBMAAIAAATg");
	this.shape_26.setTransform(105.9,81.5);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgmBbQgOgQgBgbIAWAAQABApAgAAQAOAAAIgJQAJgKAAgQQAAgWgpgeQgqgdAAgfQAAgWAOgOQAOgNAWAAQAXAAANAPQAOAPABAbIgVAAQgCgmgdAAQgNAAgIAIQgIAIAAAMQAAAVAqAdQAqAcgBAkQABAagOAOQgOAOgaAAQgXAAgPgRg");
	this.shape_27.setTransform(92.5,81.5);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgxA7IAAgQIAgAAIAAAQQAAAJAFAFQAEAFAHAAQARAAAAgaIAAgvQAAgTgPAAQgMAAgHAPIgbAAIAChqIBXAAIgCAdIg3AAIgCAuIAAAAQAHgHAGgDQAFgCAJAAQAmAAAAA2IAAAdQAAAigLAPQgMAQgZAAQgzAAAAgvg");
	this.shape_28.setTransform(73.2,81.6);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgKBpIAAhZIgxh4IAZAAIAjBcIAjhcIAYAAIgxB4IAABZg");
	this.shape_29.setTransform(53.9,81.5);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AgxA5IAAgNIAhAAIAAAOQgBAVARAAQAQAAAAgYIAAgQQAAgRgHgHQgHgGgQAAIAAgcQAPAAAHgGQAGgHAAgSQABgPgEgHQgDgGgIAAQgPAAAAAVIAAAJIghAAIAAgKQAAgWANgNQANgOAWAAQAWAAANARQAMAPAAAWQAAATgFAKQgEAMgOAHQAQAHAFAMQAFAKAAAWQAAA+gzAAQgwAAAAgzg");
	this.shape_30.setTransform(34.4,81.5);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AgRAjIAOgjIgNAAIAAgiIAiAAIAAAiIgTAjg");
	this.shape_31.setTransform(18.3,92.1);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AgBBqIAAilIgcAAIAAgTQAZgNAQgOIASAAIAADTg");
	this.shape_32.setTransform(7.6,81.3);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AvNCRQgyg1AAhcQAAhaAyg2QAxg1BUAAQBKAAAuA0IAAgsIAqAAIAACGIgsAAQgEgwgegbQgegcgwAAQg/AAgkAqQgkApAABIQAABLAkArQAkAqBAAAQBXAAAShgIA2AAQgHBDgpAjQgqAjhIAAQhXAAgyg1gASSC9IAAgnIA/AAIAAh4Ih8i0IgfAAIAAgnICQAAIAAAnIg2AAIBgCJIBdiJIg2AAIAAgnICNAAIAAAnIgfAAIiBC1IAAB3IA/AAIAAAngAN8C9IAAgnIA0AAIAAksIgEAAIh7FTIgsAAIh5lTIgCAAIAAEsIAxAAIAAAnIiVAAIAAgnIAxAAIAAksIgxAAIAAgnICKAAIBtE3IBuk3ICLAAIAAAnIgzAAIAAEsIAzAAIAAAngAC5C9IAAgnIA0AAIAAksIg0AAIAAgnIFAAAIAABzIgnAAIAAhMIiyAAIAACAIBXAAIAAg4IAnAAIAACVIgnAAIAAg3IhXAAIAACGICyAAIAAhQIAnAAIAAB3gAjKC9IAAgnIA0AAIAAksIg0AAIAAgnICoAAQBfAAA0AxQAzAxAABbQAABbgzAxQg0AxhfAAgAhjCWIBBAAQBEAAAmgoQAngnAAhHQAAhHgngnQgmgohEAAIhBAAgAmEC9IAAgnIA3AAIghhUIiqAAIgkBUIA4AAIAAAnIiVAAIAAgnIAqAAICSlTIA6AAICPFTIAqAAIAAAngAl+AbIhFijIhFCjICKAAgAyOC9IAAgnIA2AAIgghUIirAAIgkBUIA4AAIAAAnIiUAAIAAgnIAqAAICSlTIA5AAICPFTIAqAAIAAAngAyIAbIhFijIhGCjICLAAg");
	this.shape_33.setTransform(339.6,33.4);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AGaDEQhaAAgngiQgzgrAAhxQgBh0A1guQAsgnBkAAQBLABArAEQAWADAGACIgIB4Ig0AAIgHg7QgdgDgdAAQgnAAgSANQgkAaAABRQAAB+A1AGQANACA2gBIAAhNIgwgOIAAgxICQAAIAIDSgAAlC8IAHg5IAegGIgRi9IhRD8Ih3AAIhXj8IgSC9IAdAGIAIA5IiXAAIAIg5IAdgGIAbj8IgdgFIgIg6IC3AAIBTDtIBMjtIDEAAIgIA6IgdAGIAXD7IAeAGIAHA5gApBC8IAIg5IAdgGIAAj7IgdgGIgIg6IC9AAIgHA6IgdAGIAAD7IAdAGIAHA5g");
	this.shape_34.setTransform(120.5,33.5);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AjHDFIBElZIgGFUIBBmXIATG1IA1oKIA2IKIARm3IBCGaIgFlVIBEFZIjIBog");
	this.shape_35.setTransform(20,30.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logoartwork, new cjs.Rectangle(0,0,484,95.6), null);


(lib.ctabgtint = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#8FA124").s().p("Egu3AFeIAAq7MBdvAAAIAAK7g");
	this.shape.setTransform(300,35);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ctabgtint, new cjs.Rectangle(0,0,600,70), null);


(lib.ctabg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#BFD730").s().p("A3bCvIAAldMAu3AAAIAAFdg");
	this.shape.setTransform(300,35,2,2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ctabg, new cjs.Rectangle(0,0,600,70), null);


(lib.ctaarrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#002F53").s().p("AhIC0ICQiQIkZAAIAAhHIEZAAIiQiQIBmAAIC0CzIi0C0g");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ctaarrow, new cjs.Rectangle(-21,-17.9,42.1,36), null);


(lib.clickthrough = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(150,125);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.imgathlete1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.img_athlete();
	this.instance.parent = this;
	this.instance.setTransform(293,43,1.33,1.33);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.imgathlete1, new cjs.Rectangle(293,43,307.2,452.2), null);


(lib.footer = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Artwork
	this.instance = new lib.logoartwork();
	this.instance.parent = this;
	this.instance.setTransform(303,70.6,1.004,1.004,0,0,0,242,50.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// black
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Egu3AK8IAA13MBdvAAAIAAV3g");
	this.shape.setTransform(300,70);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.footer, new cjs.Rectangle(0,0,600,140), null);


(lib.ctalabellearnmore = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// FIND OUT MORE
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#112B53").s().p("AgyAjIAmhFIA/AAIg9BFg");
	this.shape.setTransform(67.6,-2.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#112B53").s().p("AhSCtIAAlZICeAAIAAA0IhiAAIAABZIBLAAIAAAzIhLAAIAABmIBpAAIAAAzg");
	this.shape_1.setTransform(252.5,21.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#112B53").s().p("AgdCtIAAklIg5AAIAAg0ICtAAIAAA0Ig5AAIAAElg");
	this.shape_2.setTransform(231.9,21.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#112B53").s().p("AhSCtIAAlZICeAAIAAA0IhjAAIAABZIBMAAIAAAzIhMAAIAABmIBqAAIAAAzg");
	this.shape_3.setTransform(212.5,21.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#112B53").s().p("AhdCtIAAlZIBYAAQBcAAAABcQAAAYgKATQgLAVgUAIQAvAUAAA9QAAAugUAaQgZAcgvAAgAghB8IAZAAQAWAAALgNQAJgNAAgbQAAgbgLgNQgMgNgZAAIgTAAgAghgeIAVAAQARAAALgLQAMgMAAgVQgBgxglAAIgXAAg");
	this.shape_4.setTransform(189.6,21.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#112B53").s().p("AgdCtIAAlZIA7AAIAAFZg");
	this.shape_5.setTransform(170.6,21.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#112B53").s().p("AAkCtIgqiPQgKABgUAAIAACOIg8AAIAAlZIBUAAQAyAAAYAXQAaAZAAA2QAABEgqASIAzCdgAgkgRIAVAAQAYAAAJgLQAKgLAAgfQAAgegKgMQgJgLgYAAIgVAAg");
	this.shape_6.setTransform(152.5,21.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#112B53").s().p("AhCCYQgXgYAAgnIAAiyQAAgmAXgYQAYgaArAAQArAAAYAcQAWAaAAApIAAAZIg8AAIAAgaQAAgWgIgLQgIgJgNgBQgQAAgHAKQgHAJAAAUIAACuQAAAVAHAIQAHAKAQAAQAQAAAHgJQAGgJAAgRIAAgpIA8AAIAAAnQAAAngWAYQgYAagrAAQgrAAgYgag");
	this.shape_7.setTransform(127.8,21.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#112B53").s().p("AhCCWQgXgbgCgpIA5gIQACAZAJAOQAKANANAAQAQAAAJgIQAKgJAAgOQAAgXgTgWQgIgJghgcQg8gyAAg2QAAgpAYgXQAYgWArAAQAkAAAWAXQAUAXAFAmIg5AGQgBgUgLgLQgIgHgMgBQgcABAAAhQAAAUATAVQAGAHAiAfQA9AzAAAzQAAAqgaAYQgaAXgpAAQgoAAgZgcg");
	this.shape_8.setTransform(105.2,21.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#112B53").s().p("AAnCtIhKjXIgBAAIAADXIg2AAIAAlZIA3AAIBHDFIABAAIAAjFIA2AAIAAFZg");
	this.shape_9.setTransform(82.7,21.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#112B53").s().p("AgdCtIAAlZIA7AAIAAFZg");
	this.shape_10.setTransform(64,21.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer 1
	this.arrow = new lib.ctaarrow();
	this.arrow.parent = this;
	this.arrow.setTransform(21.1,21.1,1,1,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

}).prototype = getMCSymbolPrototype(lib.ctalabellearnmore, new cjs.Rectangle(0,-5.6,260.8,45.2), null);


(lib.background = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// gradient over
	this.instance = new lib._25Multiply50Image();
	this.instance.parent = this;
	this.instance.setTransform(300,63,2,1.999,0,0,0,150,31.5);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// shape
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(16,113,183,0.4)").s().p("AmTM6IMn5zIAAAQInOZjg");
	this.shape.setTransform(517.5,333.8,1.994,1.994);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(16,113,183,0.4)").s().p("ApxTiIktmmIAAlAIVl7cMgRNAgfMAXngggIA+AAIrzaEImBM/g");
	this.shape_1.setTransform(184.8,249.2,1.994,1.994);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(16,113,183,0.4)").s().p("AtsTiMAZRgnDICJAAMgPDAnDg");
	this.shape_2.setTransform(317.9,249.2,1.994,1.994);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(16,113,183,0.4)").s().p("Ap/R3MAT/gjtMgLfAjtg");
	this.shape_3.setTransform(440.7,270.5,1.994,1.994);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(16,113,183,0.4)").s().p("AgEADIAJgUIgJAjg");
	this.shape_4.setTransform(599,168.7,1.994,1.994);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(16,113,183,0.4)").s().p("AAEgMIAEAAIgPAZg");
	this.shape_5.setTransform(141.3,501,1.994,1.994);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// 300x250
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["#002D54","#006FBA"],[0.514,1],8.3,-78.2,8.3,185.1).s().p("Egu3AnEMAAAhOHMBdvAAAMAAABOHg");
	this.shape_6.setTransform(300,250);

	this.timeline.addTween(cjs.Tween.get(this.shape_6).wait(1));

}).prototype = getMCSymbolPrototype(lib.background, new cjs.Rectangle(0,0,600,503.5), null);


(lib.ctalearnmoreon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// label
	this.cta_label = new lib.ctalabellearnmore();
	this.cta_label.parent = this;
	this.cta_label.setTransform(306.4,41,1,1,0,0,0,137.4,26);
	this.cta_label.filters = [new cjs.ColorFilter(0, 0, 0, 1, 255, 255, 255, 0)];
	this.cta_label.cache(-2,-8,265,49);

	this.timeline.addTween(cjs.Tween.get(this.cta_label).wait(1));

	// cta_bg
	this.instance = new lib.ctabgtint();
	this.instance.parent = this;
	this.instance.setTransform(300,35,1,1,0,0,0,300,35);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ctalearnmoreon, new cjs.Rectangle(0,0,600,70), null);


(lib.ctalearnmoreoff = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// cta_label
	this.cta_label = new lib.ctalabellearnmore();
	this.cta_label.parent = this;
	this.cta_label.setTransform(306.4,41,1,1,0,0,0,137.4,26);

	this.timeline.addTween(cjs.Tween.get(this.cta_label).wait(1));

	// cta_bg
	this.cta_bg = new lib.ctabg();
	this.cta_bg.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.cta_bg).wait(1));

}).prototype = getMCSymbolPrototype(lib.ctalearnmoreoff, new cjs.Rectangle(0,0,600,70), null);


(lib.ctalearnmore = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.cta_on.alpha = 0;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// cta-on
	this.cta_on = new lib.ctalearnmoreon();
	this.cta_on.parent = this;
	this.cta_on.setTransform(300,35,1,1,0,0,0,300,35);

	this.timeline.addTween(cjs.Tween.get(this.cta_on).wait(1));

	// cta-off
	this.cta_off = new lib.ctalearnmoreoff();
	this.cta_off.parent = this;
	this.cta_off.setTransform(300,35,1,1,0,0,0,300,35);

	this.timeline.addTween(cjs.Tween.get(this.cta_off).wait(1));

}).prototype = getMCSymbolPrototype(lib.ctalearnmore, new cjs.Rectangle(0,0,600,70), null);


// stage content:
(lib.index = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/**
		 * Squarewave CreateJS Template 1.1 (September 2016)
		 **/
		var root = this;
		
		var stageHeight = stage.canvas.height;
		var stageWidth = stage.canvas.width;
		
		// cta
		var ctaHeight = 70; // need to get this dynamically
		var ctaOpenY = root.cta.y;
		var ctaOffset = 6; // how many pixels of the cta should be visible behind the
		var ctaClosedY = ctaOpenY + ctaHeight - ctaOffset;
		
		
		var mainTl = new TimelineMax();
		
		/**** uncomment to use within creative ******/
		/*
		root.clickthrough.on('mouseover' , onRollOver );
		root.clickthrough.on('mouseout' , onRollOut );
		root.clickthrough.on('click' , onClick );
		*/
		
		this.onInit = function () {
			this.animate();
		}
		
		// banner animation
		this.animate = function () {
			
			mainTl.add('start', 0.2)
		
			// frame 1 animation
			.from(root.athlete_1, 1.2, {
				scaleX: 1.5,
				scaleY: 1.5,
				alpha: 0,
				ease: Strong.easeOut
			}, 'start')
			.from(root.facilities, 1, {
				y: stageHeight,
				ease: Strong.easeOut
			}, 'start')
			.from(root.text_1, 1, {
					alpha: 0,
					y: '+=100',
					ease: Strong.easeOut
				}, 'start+=0.2')
				.from(root.footer, 0.75, {
					y: stageHeight,
					ease: Strong.easeOut
				}, 'start')
				.fromTo(root.cta, 0.75, {
					y: stageHeight
				}, {
					y: ctaClosedY,
					ease: Strong.easeOut
				}, 'start')
		
			// frame 2
			.add('frame2', '+=1')
				.to(root.text_1, 0.5, {
					alpha: 0,
					ease: Strong.easeOut
				}, 'frame2')
				.from(root.text_2, 0.65, {
					alpha: 0,
					y: '+=100',
					ease: Strong.easeOut
				}, 'frame2+=0.75')
				
				// Athlete transition
				/*.to(root.athlete_1, 1.8, {
				x: '-=' + (stageWidth + 100),
				ease: Strong.easeOut
				}, 'frame2')
				.from(root.athlete_2, 1.8, {
				x: '+=' + stageWidth,
				ease: Strong.easeOut
				}, 'frame2+=0.35')*/
				
		
			// transition to end frame 
			.add('frame3', '+=1.5')
				.to(root.text_2, 0.5, {
					alpha: 0,
					ease: Strong.easeOut
				}, 'frame3')
			.to(root.athlete_1, 0.5, {
					alpha: 0,
					scaleX: 1.5,
					scaleY: 1.5,
					ease: Strong.easeIn
				}, 'frame3')
			.to(root.facilities, 0.5, {
				y: stageHeight,
				alpha: 0,
				ease: Strong.easeOut
			}, 'frame3')
		
			.add('endFrame')
				.from(root.text_3, 0.65, {
					alpha: 0,
					scaleX: 0.6,
					scaleY: 0.6,
					ease: Strong.easeOut
				}, 'endFrame')
				.to(root.cta, 0.6, {
					y: ctaOpenY,
					ease: Back.easeOut.config(0.5),
					onComplete: this.ctaOpen
				}, 'endFrame+=0.6');
		}
		
		var ctaIsOpen = false;
		// only do the rollover on the cta if it's open/visible
		this.ctaOpen = function () {
			if (!ctaIsOpen) {
				ctaIsOpen = true;
			}
		}
		
		// mouse over/mouse out events
		this.onRollOverEvent = function (e) {
			// wake up creative if asleep //
			if (root.adHelper && !root.adHelper.awake) root.adHelper.wake();
		
			if (ctaIsOpen) TweenMax.to(root.cta.cta_on, 0.2, {
				alpha: 1
			});
		}
		
		this.onRollOutEvent = function (e) {
			if (ctaIsOpen) TweenMax.to(root.cta.cta_on, 0.2, {
				alpha: 0
			});
		}
		
		this.onClickEvent = function (e) {
			console.log("creative-click");
		}
		
		
		
		
		
		
		/**
		 * AD HELPER METHODS
		 *
		 * If everything is setup correctly, you can use
		 * root.adHelper.sleep() & root.adHelper.wake()
		 * to manually control AdHelper.
		 * NOTE: sleep() pauses CreateJS AND TweenLite
		 *
		 **/
		this.adHelper = null; // adhelper reference //
		this.onSlowDown = function () {
			console.log("creative-slowdown");
		}
		
		this.onSleep = function () {
			console.log("creative-sleep");
		}
		
		this.onWake = function () {
			console.log("creative-wake");
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// clickthrough
	this.clickthrough = new lib.clickthrough();
	this.clickthrough.parent = this;
	this.clickthrough.setTransform(300,250,2,2,0,0,0,150,125);
	new cjs.ButtonHelper(this.clickthrough, 0, 1, 2, false, new lib.clickthrough(), 3);

	this.timeline.addTween(cjs.Tween.get(this.clickthrough).wait(1));

	// footer
	this.footer = new lib.footer();
	this.footer.parent = this;
	this.footer.setTransform(150,395,1,1,0,0,0,150,35);

	this.timeline.addTween(cjs.Tween.get(this.footer).wait(1));

	// cta
	this.cta = new lib.ctalearnmore();
	this.cta.parent = this;
	this.cta.setTransform(0,292);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// text: headline 3
	this.text_3 = new lib.textheadline3();
	this.text_3.parent = this;
	this.text_3.setTransform(300,142.1,1,1,0,0,0,300,142.1);
	this.text_3.cache(23,87,553,120);

	this.timeline.addTween(cjs.Tween.get(this.text_3).wait(1));

	// text: headline 2
	this.text_2 = new lib.textheadline2();
	this.text_2.parent = this;
	this.text_2.cache(26,44,352,161);

	this.timeline.addTween(cjs.Tween.get(this.text_2).wait(1));

	// text: headline 1
	this.text_1 = new lib.textheadline1();
	this.text_1.parent = this;
	this.text_1.cache(29,43,343,167);

	this.timeline.addTween(cjs.Tween.get(this.text_1).wait(1));

	// athlete_1
	this.athlete_1 = new lib.imgathlete1();
	this.athlete_1.parent = this;
	this.athlete_1.setTransform(510.4,248.9,1,1,0,0,0,510.4,248.9);

	this.timeline.addTween(cjs.Tween.get(this.athlete_1).wait(1));

	// image: facilities
	this.facilities = new lib.img_facilities_1();
	this.facilities.parent = this;
	this.facilities.setTransform(224.5,187.5,1,1,0,0,0,224.5,187.5);

	this.timeline.addTween(cjs.Tween.get(this.facilities).wait(1));

	// background
	this.bg = new lib.background();
	this.bg.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(300,250,600.2,503.5);
// library properties:
lib.properties = {
	width: 600,
	height: 500,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/img_athlete.png?1481835848749", id:"img_athlete"},
		{src:"images/img_facilities.png?1481835848749", id:"img_facilities"}
	],
	preloads: []
};




})(lib = lib||{}, images = images||{}, createjs = createjs||{}, ss = ss||{}, AdobeAn = AdobeAn||{});
var lib, images, createjs, ss, AdobeAn;