(function (lib, img, cjs, ss, an) {

var p; // shortcut to reference prototypes
lib.ssMetadata = [];


// symbols:



(lib.BlueGradientImage = function() {
	this.initialize(img.BlueGradientImage);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,160,600);


(lib.img_athlete1 = function() {
	this.initialize(img.img_athlete1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,291,576);


(lib.img_athlete2 = function() {
	this.initialize(img.img_athlete2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,226,441);


(lib.img_facilities = function() {
	this.initialize(img.img_facilities);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,240,900);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.shape_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0072B8").s().p("EgoEAO2MAmfgw1MgcPA1MMAq8g7EMgV9AwiIqOV7MAyfhN7MghZBWnILv1IMAaOguuMgWjBF/IAEAAMAakg2QMgQ8A70Mgn+AAWg");
	this.shape.setTransform(256.5,303);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.shape_0, new cjs.Rectangle(0,0,513,605.9), null);


(lib.textheadline3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgqBaIAAizIBSAAIAAAbIgzAAIAAAuIAnAAIAAAaIgnAAIAAA1IA2AAIAAAbg");
	this.shape.setTransform(253.8,513.6,2.167,2.167);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AATBaIgVhLIgQABIAABKIgfAAIAAizIArAAQAaAAAMAMQAOANAAAcQAAAkgWAIIAaBSgAgSgIIALAAQALAAAFgGQAGgGAAgQQAAgQgGgGQgFgGgLAAIgLAAg");
	this.shape_1.setTransform(228.8,513.6,2.167,2.167);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgqBaIAAizIBSAAIAAAbIgzAAIAAAuIAmAAIAAAaIgmAAIAAA1IA2AAIAAAbg");
	this.shape_2.setTransform(203.7,513.6,2.167,2.167);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAQBaIAAhQIgfAAIAABQIgfAAIAAizIAfAAIAABJIAfAAIAAhJIAfAAIAACzg");
	this.shape_3.setTransform(179,513.6,2.167,2.167);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAXBaIgWh2IgBAAIgUB2IgaAAIgiizIAdAAIATByIABAAIAUhyIAYAAIAVByIABAAIARhyIAdAAIggCzg");
	this.shape_4.setTransform(146.8,513.6,2.167,2.167);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgPBaIAAhLIglhoIAgAAIAUBEIABAAIAUhEIAgAAIglBoIAABLg");
	this.shape_5.setTransform(115.3,513.6,2.167,2.167);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAUBaIgmhwIAAAAIAABwIgdAAIAAizIAdAAIAlBmIABAAIAAhmIAcAAIAACzg");
	this.shape_6.setTransform(89.6,513.6,2.167,2.167);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAWBaIgFgoIghAAIgGAoIgeAAIAiizIAlAAIAiCzgAgMAXIAYAAIgMhMIAAAAg");
	this.shape_7.setTransform(64.4,513.6,2.167,2.167);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("Ag0BuIAAjbIBkAAIAAAhIg+AAIAAA5IAwAAIAAAgIgwAAIAABAIBDAAIAAAhg");
	this.shape_8.setTransform(251.8,463.6,2.167,2.167);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgSBuIAAi6IgkAAIAAghIBuAAIAAAhIglAAIAAC6g");
	this.shape_9.setTransform(223.4,463.6,2.167,2.167);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgzBuIAAjbIBkAAIAAAhIg/AAIAAA5IAwAAIAAAgIgwAAIAABAIBCAAIAAAhg");
	this.shape_10.setTransform(196.2,463.6,2.167,2.167);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("Ag8BuIAAjbIA2AAQAjAAAQAPQAQAPAAAjQAAAjgQAOQgQAPgjAAIgQAAIAABagAgWgKIAOAAQASAAAHgHQAHgHAAgUQAAgTgHgIQgHgHgSAAIgOAAg");
	this.shape_11.setTransform(167.7,463.6,2.167,2.167);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAsBuIAAirIgBAAIgiCrIgRAAIgiirIgBAAIAACrIghAAIAAjbIAyAAIAaCAIAAAAIAbiAIAyAAIAADbg");
	this.shape_12.setTransform(131.2,463.6,2.167,2.167);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgrBgQgOgPAAgYIAAhxQAAgYAOgPQAQgRAbAAQAcAAAQARQAOAPAAAYIAABxQAAAYgOAPQgQARgcAAQgbAAgQgRgAgPhJQgEAGAAAMIAABvQAAANAEAFQAFAGAKAAQAMAAAEgGQAEgFAAgNIAAhvQAAgNgEgFQgEgGgMAAQgKAAgFAGg");
	this.shape_13.setTransform(95.6,463.6,2.167,2.167);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgqBgQgOgPAAgYIAAhxQAAgYAOgPQAPgRAcAAQAbAAAPASQAOAQAAAaIAAARIgmAAIAAgSQAAgagSAAQgKAAgFAGQgEAGAAAMIAABvQAAANAEAFQAFAGAKAAQASAAAAgWIAAgbIAmAAIAAAaQAAAYgOAPQgPARgbAAQgcAAgPgRg");
	this.shape_14.setTransform(65.6,463.6,2.167,2.167);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AheDHIAAmNIC2AAIAAA7IhyAAIAABnIBXAAIAAA7IhXAAIAAB1IB6AAIAAA7g");
	this.shape_15.setTransform(242.5,374.8,2.167,2.167);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAqDHIgxilQgMACgWAAIAACjIhFAAIAAmNIBgAAQA6AAAbAbQAeAcAAA+QAABPgwAVIA6C0gAgpgTIAXAAQAcAAALgNQAMgOAAgjQAAgjgMgNQgLgNgcAAIgXAAg");
	this.shape_16.setTransform(187.2,374.8,2.167,2.167);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AheDHIAAmNIC1AAIAAA7IhxAAIAABnIBXAAIAAA7IhXAAIAAB1IB5AAIAAA7g");
	this.shape_17.setTransform(131.8,374.8,2.167,2.167);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AAlDHIAAiwIhIAAIAACwIhFAAIAAmNIBFAAIAACiIBIAAIAAiiIBEAAIAAGNg");
	this.shape_18.setTransform(76,374.8,2.167,2.167);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AhmC4IAAlvIBbAAQA7AAAbAZQAbAZABA7QgBA6gbAYQgbAZg7AAIgbAAIAACXgAgmgSIAYAAQAeAAAMgMQALgMAAggQAAgigLgLQgMgMgeAAIgYAAg");
	this.shape_19.setTransform(242.4,284.7,2.167,2.167);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("ABJC4IAAkeIgBAAIg5EeIgdAAIg6keIgBAAIAAEeIg3AAIAAlvIBTAAIAtDWIAAAAIAtjWIBUAAIAAFvg");
	this.shape_20.setTransform(181.3,284.7,2.167,2.167);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AAuC4IgLhSIhFAAIgKBSIg+AAIBElvIBNAAIBEFvgAgZAvIAzAAIgZidIgBAAg");
	this.shape_21.setTransform(122.2,284.7,2.167,2.167);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AhHCiQgXgaAAgpIAAi9QAAgpAXgZQAagcAvAAQAtAAAZAeQAXAbAAAsIAAAbIg/AAIAAgdQAAgWgJgMQgIgKgNAAQgSAAgIAKQgHAJAAAWIAAC5QAAAWAHAJQAIAKASAAQAeAAAAglIAAgsIA/AAIAAAqQAAApgXAaQgZAbgtAAQgvAAgagbg");
	this.shape_22.setTransform(73.9,284.6,2.167,2.167);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.textheadline3, new cjs.Rectangle(0,0,320,1200), null);


(lib.textheadline2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AA/D1Ig9lDIgBAAIg4FDIhHAAIhdnpIBPAAIAzE3IACAAIA3k3IBEAAIA5E3IACAAIAvk3IBOAAIhWHpg");
	this.shape.setTransform(268.7,218.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag4DzQgZgKgPgRQgRgRgHgYQgIgWAAgaIAAj8QAAgbAIgXQAHgWARgRQAPgSAZgJQAZgKAfAAQAgAAAaAKQAYAJAPASQAQARAJAWQAHAXAAAbIAAD8QAAAagHAWQgJAYgQARQgPARgYAKQgaAJggAAQgfAAgZgJgAgiikQgKAMAAAcIAAD5QAAAcAKAMQAKAOAYAAQAZAAAKgOQAKgMAAgcIAAj5QAAgcgKgMQgKgOgZAAQgYAAgKAOg");
	this.shape_1.setTransform(232.6,218.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAzD1Ig7jKIgsACIAADIIhTAAIAAnpIB1AAQAkAAAaAHQAbAJASAQQARASAKAbQAJAcgBAoQABAcgGAWQgEAVgJAPQgIANgLAKQgKAHgMAGIBHDegAg0gYIAfAAQARAAALgEQAMgEAHgIQAHgJADgOQAEgPAAgVQAAgXgEgOQgDgPgHgIQgHgJgMgDQgLgEgRAAIgfAAg");
	this.shape_2.setTransform(202.2,218.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAzD1Ig7jKIgrACIAADIIhVAAIAAnpIB3AAQAiAAAbAHQAbAJARAQQATASAIAbQAJAcAAAoQAAAcgEAWQgFAVgKAPQgHANgMAKQgJAHgMAGIBIDegAgzgYIAdAAQASAAAKgEQAMgEAIgIQAHgJAEgOQADgPAAgVQAAgXgDgOQgEgPgHgIQgIgJgMgDQgKgEgSAAIgdAAg");
	this.shape_3.setTransform(171.1,218.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Ag5DzQgXgKgQgRQgQgRgJgYQgHgWAAgaIAAj8QAAgbAHgXQAJgWAQgRQAQgSAXgJQAagKAfAAQAgAAAZAKQAYAJARASQAQARAHAWQAIAXAAAbIAAD8QAAAagIAWQgHAYgQARQgRARgYAKQgZAJggAAQgfAAgagJgAgiikQgKAMAAAcIAAD5QAAAcAKAMQAKAOAYAAQAZAAAKgOQAKgMAAgcIAAj5QAAgcgKgMQgKgOgZAAQgYAAgKAOg");
	this.shape_4.setTransform(139.3,218.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("ABiD1IAAl+IgCAAIhLF+IgpAAIhLl+IgCAAIAAF+IhKAAIAAnpIBwAAIA7EdIABAAIA7kdIBwAAIAAHpg");
	this.shape_5.setTransform(104.4,218.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ag4DzQgYgKgRgRQgQgRgHgYQgIgWAAgaIAAj8QAAgbAIgXQAHgWAQgRQARgSAYgJQAZgKAfAAQAgAAAaAKQAXAJAQASQAQARAJAWQAHAXAAAbIAAD8QAAAagHAWQgJAYgQARQgQARgXAKQgaAJggAAQgfAAgZgJgAgiikQgKAMAAAcIAAD5QAAAcAKAMQAKAOAYAAQAZAAAKgOQAKgMAAgcIAAj5QAAgcgKgMQgKgOgZAAQgYAAgKAOg");
	this.shape_6.setTransform(69.6,218.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgpD1IAAmgIhRAAIAAhJID1AAIAABJIhRAAIAAGgg");
	this.shape_7.setTransform(42.2,218.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("ACNJtIkPsHIgDAAIAAMHIjBAAIAAzZIDFAAIEELFIAEAAIAArFIDAAAIAATZg");
	this.shape_8.setTransform(256.7,122.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("ACgJtIibszIgDAAIiPMzIizAAIjszZIDIAAICCMWIADAAICMsWICuAAICRMWIADAAIB3sWIDHAAIjaTZg");
	this.shape_9.setTransform(158.2,122.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AiRJlQg8gXgpgtQgogqgVg7QgSg5gBhCIAAp/QABhEASg5QAVg6AogqQApgtA8gYQBBgZBQAAQBRAABBAZQA8AYApAtQAoAqAVA6QASA5ABBEIAAJ/QgBBCgSA5QgVA7goAqQgpAtg8AXQhBAZhRAAQhQAAhBgZgAhYmhQgZAfABBIIAAJ0QgBBIAZAhQAaAhA+AAQA/AAAaghQAZghgBhIIAAp0QABhIgZgfQgagig/AAQg+AAgaAig");
	this.shape_10.setTransform(63,122.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.textheadline2, new cjs.Rectangle(18,58,280.4,206), null);


(lib.textheadline1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// text
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ACfJqIiZswIgEAAIiPMwIiyAAIjqzTIDGAAICCMSIADAAICLsSICtAAICQMSIADAAIB3sSIDGAAIjZTTg");
	this.shape.setTransform(234.4,187.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AiPJiQg8gXgpguQgogpgVg7QgTg5AAhCIAAp6QAAhDATg5QAVg6AogqQApgsA8gYQA/gZBQAAQBRAAA/AZQA9AYAoAsQApAqAUA6QATA5AABDIAAJ6QAABCgTA5QgUA7gpApQgoAug9AXQg/AYhRAAQhQAAg/gYgAhYmeQgYAeABBIIAAJxQgBBHAYAgQAaAiA+gBQA+ABAbgiQAYggAAhHIAApxQAAhIgYgeQgbgjg+AAQg+AAgaAjg");
	this.shape_1.setTransform(142.3,187.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("ACMJqIkOsDIgCAAIAAMDIjAAAIAAzTIDEAAIECLCIAEAAIAArCIC/AAIAATTg");
	this.shape_2.setTransform(62.8,187.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AiUE3IAApsIEdAAIAABdIiyAAIAACfICJAAIAABcIiJAAIAAC2IC+AAIAABeg");
	this.shape_3.setTransform(276.1,81.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("ABBE3IhLkBIg3ACIAAD/IhrAAIAApsICWAAQAtAAAhAKQAiAKAWAVQAXAWALAjQALAkAAAxQAAAjgGAdQgGAagLATQgKARgOAMQgMAKgPAHIBaEagAhBgeIAmAAQAWgBANgEQAQgFAJgLQAJgLAFgSQAEgTAAgbQAAgcgEgSQgFgTgJgKQgJgLgQgFQgNgFgWAAIgmAAg");
	this.shape_4.setTransform(238.2,81.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("ABNE3IgTiKIh0AAIgTCKIhmAAIBxpsICEAAIBzJsgAArBQIgqkKIgBAAIgqEKIBVAAg");
	this.shape_5.setTransform(199.5,81.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AisE3IAApsICZAAQAyAAAjAKQAkAKAYAVQAYAWAMAjQALAjAAAyQAAAygLAiQgMAjgYAVQgYAWgkAKQgjAKgyAAIguAAIAAD/gAhBgeIApAAQAagBARgEQASgFAKgLQALgLAEgSQAEgSAAgcQAAgcgEgSQgEgTgLgKQgKgLgSgFQgRgFgaAAIgpAAg");
	this.shape_6.setTransform(162.5,81.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AiUE3IAApsIEdAAIAABdIiyAAIAACfICJAAIAABcIiJAAIAAC2IC+AAIAABeg");
	this.shape_7.setTransform(124.6,81.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("ABBE3IhLkBIg3ACIAAD/IhrAAIAApsICWAAQAtAAAhAKQAiAKAWAVQAXAWALAjQALAkAAAxQAAAjgGAdQgGAagLATQgKARgOAMQgMAKgPAHIBaEagAhBgeIAmAAQAWgBANgEQAQgFAJgLQAJgLAFgSQAEgTAAgbQAAgcgEgSQgFgTgJgKQgJgLgQgFQgNgFgWAAIgmAAg");
	this.shape_8.setTransform(86.7,81.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AisE3IAApsICZAAQAyAAAjAKQAkAKAYAVQAYAWAMAjQALAjAAAyQAAAygLAiQgMAjgYAVQgYAWgkAKQgjAKgyAAIguAAIAAD/gAhBgeIApAAQAagBARgEQASgFAKgLQALgLAEgSQAEgSAAgcQAAgcgEgSQgEgTgLgKQgKgLgSgFQgRgFgaAAIgpAAg");
	this.shape_9.setTransform(46.4,81.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.textheadline1, new cjs.Rectangle(18,48,275.8,251), null);


(lib.img_facilities_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.img_facilities();
	this.instance.parent = this;
	this.instance.setTransform(0,0,1.333,1.333);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.img_facilities_1, new cjs.Rectangle(0,0,320,1200), null);


(lib.logoartwork = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Artwork
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgeBIQgLgMAAgWIARAAQABAhAZgBQALABAHgIQAGgHAAgNQABgSghgXQghgXgBgZQAAgRALgLQAMgKARAAQASAAALALQAKANACAVIgRAAQgDgegWAAQgKAAgGAGQgGAGAAAKQAAARAgAWQAhAWAAAdQABAUgMALQgLAMgUAAQgTAAgLgOg");
	this.shape.setTransform(173.2,266.9,1.173,1.173);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgpBTIAAilIAnAAQATAAANAMQAMANAAAUQAAAVgMANQgNALgTAAIgVAAIAABLgAgXgGIATAAQAcAAAAgfQAAgegcAAIgTAAg");
	this.shape_1.setTransform(161.7,266.9,1.173,1.173);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAoBTIAAiXIgjCXIgKAAIgjiXIAAAAIAACXIgRAAIAAilIAdAAIAcB9IABAAIAch9IAcAAIAAClg");
	this.shape_2.setTransform(147,266.9,1.173,1.173);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAfBTIgKgxIgqAAIgJAxIgSAAIAkilIAYAAIAlClgAgRASIAkAAIgThYIAAAAg");
	this.shape_3.setTransform(132.8,266.9,1.173,1.173);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AggBDQgOgWAAgtQAAgtAOgUQALgUAXABQAmAAAEA0IgSAAQgEglgUAAQgPAAgIAPQgHARAAAlQAAAnAHAQQAIAPAPAAQAaABABgrIASAAQgBAcgMAOQgLAQgVAAQgXAAgLgTg");
	this.shape_4.setTransform(120,266.9,1.173,1.173);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAZBTIgahOIgYABIAABNIgSAAIAAilIApAAQATAAANALQANAMgBAUQAAAggaAIIAbBSgAgZgJIAQAAQASgBAIgHQAHgHAAgOQAAgOgHgIQgIgHgSAAIgQAAg");
	this.shape_5.setTransform(100.6,266.9,1.173,1.173);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgmBTIAAilIBLAAIAAAPIg5AAIAAA5IApAAIAAAOIgpAAIAABAIA7AAIAAAPg");
	this.shape_6.setTransform(88.2,266.9,1.173,1.173);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AApBTIAAiXIgBAAIgiCXIgLAAIgjiXIAAAAIAACXIgRAAIAAilIAdAAIAcB9IABAAIAch9IAdAAIAAClg");
	this.shape_7.setTransform(73.5,266.9,1.173,1.173);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AApBTIAAiXIgBAAIgiCXIgLAAIgiiXIgBAAIAACXIgQAAIAAilIAcAAIAcB9IABAAIAch9IAcAAIAAClg");
	this.shape_8.setTransform(57,266.9,1.173,1.173);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgfBHQgKgMAAgVIAAh5IASAAIAAB5QAAAfAXAAQAYAAAAgfIAAh5IASAAIAAB5QAAAVgKAMQgLANgVAAQgUAAgLgNg");
	this.shape_9.setTransform(42,267,1.173,1.173);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgeBIQgLgMAAgWIAQAAQABAhAagBQALABAHgIQAGgHAAgNQAAgSgggXQgigXAAgZQAAgRALgLQAMgKARAAQARAAALALQAMANAAAVIgQAAQgDgegWAAQgKAAgGAGQgGAGAAAKQAAARAgAWQAhAWAAAdQAAAUgLALQgLAMgUAAQgSAAgMgOg");
	this.shape_10.setTransform(29.2,266.9,1.173,1.173);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAWBsIgehlIAAAAIgNAZIAABMIglAAIAAjYIAlAAIAABQIABAAIAlhQIAlAAIgnBRIAtCHg");
	this.shape_11.setTransform(180.8,236,1.173,1.173);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgzBsIAAjYIBjAAIAAAhIg+AAIAAA3IAvAAIAAAgIgvAAIAABAIBCAAIAAAgg");
	this.shape_12.setTransform(164.5,236,1.173,1.173);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgzBsIAAjYIBjAAIAAAhIg9AAIAAA3IAuAAIAAAgIguAAIAABAIBBAAIAAAgg");
	this.shape_13.setTransform(148.8,236,1.173,1.173);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAcBsIgbiOIgBAAIgYCOIgfAAIgpjYIAiAAIAXCKIABAAIAYiKIAeAAIAZCKIABAAIAUiKIAjAAIgmDYg");
	this.shape_14.setTransform(128.5,236,1.173,1.173);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgjBjQgQgNAAgZIAAgRIAiAAIAAASQgBAIAFAFQAEAGAIAAQARAAAAgbIAAgxQAAgTgPAAQgNAAgHAPIgcAAIADhuIBZAAIgCAeIg5AAIgCAvIABABQAGgHAHgEQAFgCAJAAQAoAAAAA4IAAAfQAAAigMAQQgMARgaAAQgXAAgOgLg");
	this.shape_15.setTransform(101.5,236.2,1.173,1.173);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("Ag2BgQgQgOABgaQAAgUAMgUIAXgZQgPghAAgXQAAgWALgMQAKgMAQAAQARAAAMAMQALALAAAPQAAAVgMAQQgGAKgTATQAQAiAWAZQAGgRADggIAVACQgCAkgNAcQALAMAQALIgNAQQgOgHgNgNQgTAXgaABQgZgBgPgPgAgpAdQgHANAAAMQAAARAJAKQAKALARAAQARAAANgSQgYgdgTgmQgJAKgHAMgAgbhCQgBAPALAaQAMgOAFgKQAGgMAAgOQAAgIgEgGQgEgFgGAAQgUAAABAcg");
	this.shape_16.setTransform(76.3,236,1.173,1.173);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgzA7IAAgOIAiAAIAAAPQAAAWAQAAQARAAAAgZIAAgRQAAgRgHgIQgHgGgQAAIAAgdQAPAAAHgGQAHgIAAgTQAAgPgDgGQgEgHgIAAQgQAAAAAWIAAAJIghAAIAAgKQAAgXAMgNQAOgOAXgBQAXABANARQANAOAAAYQAAAUgFALQgFALgOAIQAQAIAGALQAFALAAAXQAAA/g1ABQgyAAAAg1g");
	this.shape_17.setTransform(50.5,236,1.173,1.173);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgRAkIAOgkIgNAAIAAgjIAiAAIAAAjIgTAkg");
	this.shape_18.setTransform(31,248.8,1.173,1.173);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgBBuIAAirIgeAAIAAgUQAegPAOgNIASAAIAADbg");
	this.shape_19.setTransform(18,235.8,1.173,1.173);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Artwork
	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AsoMZIEU1xIgXVgIEF5wIA5TAIATIoMADagg9MADbAg9IBE7uIELZ6IACgBIgX1jIEUVxIspGlg");
	this.shape_20.setTransform(101,47.4,0.39,0.39);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AcwNuQjEAAiBgdQicgjhlhVQjkjAAAoAQAAoKDrjOQBthfCogqQCVglDaAAQFUAADAAVQBgALAcAKIghIZIjqAAIghkDQiEgPh/AAQhUAAgjAFQhSAMg5AqQijB2AAFrQABFpBjCQQA1BMBYAMQA4AIDzgEIAAlbIjVg7IAAjiIKEAAIAiOxgACnNOIAhkFICEgXIhPtTIluRvIoVAAImHxxIhRNVICEAXIAiEFIqjAAIAikFICEgXIB4xtIiEgXIghkEIM2AAIFyQoIFcwnINsAAIghEFIiFAXIBpRrICEAXIAhEFgEgodANOIAikFICEgXIAAxrIiEgXIgikFINQAAIgiEFIiEAXIAARrICEAXIAiEFg");
	this.shape_21.setTransform(101,141.3,0.39,0.39);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("Ah6CQQgyg1AAhbQAAhZAyg2QAwg0BTAAQBJAAAuAyIAAgqIApAAIAACEIgrAAQgEgvgegbQgegcgwABQg8gBglApQgjAqgBBHQABBLAjAqQAlAqA9AAQBXAAAShgIA1AAQgHBDgoAiQgpAjhJAAQhVAAgxg0g");
	this.shape_22.setTransform(68.1,194.4,0.39,0.39);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AA9C8IAAgnIA2AAIgghTIioAAIgkBTIA4AAIAAAnIiTAAIAAgnIApAAICRlQIA4AAICOFQIApAAIAAAngABDAbIhDihIhFChICIAAg");
	this.shape_23.setTransform(83.6,194.4,0.39,0.39);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("Ai1C8IAAgnIAzAAIAAkpIgzAAIAAgnICnAAQBeAAAzAxQAzAwAABaQAABbgzAwQgzAxheAAgAhPCVIBBAAQBDAAAmgnQAmgnAAhHQAAhGgmgnQgmgnhDAAIhBAAg");
	this.shape_24.setTransform(100.2,194.4,0.39,0.39);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AA9C8IAAgnIA2AAIgghTIioAAIgkBTIA4AAIAAAnIiTAAIAAgnIApAAICRlQIA4AAICOFQIApAAIAAAngABDAbIhDihIhFChICIAAg");
	this.shape_25.setTransform(53.5,194.4,0.39,0.39);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AhZC8IAAgnIA+AAIAAh3Ih7iyIgeAAIAAgnICOAAIAAAnIg2AAIBfCHIBciHIg2AAIAAgnICMAAIAAAnIgeAAIiACzIAAB2IA+AAIAAAng");
	this.shape_26.setTransform(149.8,194.4,0.39,0.39);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("ABcC8IAAgnIA1AAIAAkpIgEAAIh6FQIgrAAIh4lQIgCAAIAAEpIAxAAIAAAnIiUAAIAAgnIAxAAIAAkpIgxAAIAAgnICJAAIBsE0IBtk0ICJAAIAAAnIgzAAIAAEpIAzAAIAAAng");
	this.shape_27.setTransform(131.9,194.4,0.39,0.39);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AieC8IAAgnIA0AAIAAkpIg0AAIAAgnIE9AAIAAByIgnAAIAAhLIivAAIAAB/IBVAAIAAg4IAnAAIAACUIgnAAIAAg3IhVAAIAACFICvAAIAAhPIAnAAIAAB2g");
	this.shape_28.setTransform(114.3,194.4,0.39,0.39);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logoartwork, new cjs.Rectangle(0,0,202,276.9), null);


(lib.ctabgtint = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#8FA124").s().p("A4/FeIAAq7MAx/AAAIAAK7g");
	this.shape.setTransform(160,35);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ctabgtint, new cjs.Rectangle(0,0,320,70), null);


(lib.ctabg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#BFD730").s().p("A4/FeIAAq7MAx/AAAIAAK7g");
	this.shape.setTransform(160,35);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ctabg, new cjs.Rectangle(0,0,320,70), null);


(lib.ctaarrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#002F53").s().p("AhIC0ICQiQIkZAAIAAhHIEZAAIiQiQIBmAAIC0CzIi0C0g");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ctaarrow, new cjs.Rectangle(-21,-17.9,42.1,36), null);


(lib.clickthrough = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(150,125);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.imgathlete2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.img_athlete2();
	this.instance.parent = this;
	this.instance.setTransform(19,286,1.332,1.332);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.imgathlete2, new cjs.Rectangle(19,286,301,587.4), null);


(lib.imgathlete1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.img_athlete1();
	this.instance.parent = this;
	this.instance.setTransform(44,300,1.342,1.342);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.imgathlete1, new cjs.Rectangle(44,300,390.6,773.2), null);


(lib.shape = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.shape_0();
	this.instance.parent = this;
	this.instance.setTransform(256.4,302.9,1,1,0,0,0,256.4,302.9);
	this.instance.alpha = 0.398;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.shape, new cjs.Rectangle(0,0,513,605.9), null);


(lib.ClipGroup = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
	mask.setTransform(337,300);

	// Layer 3
	this.instance = new lib.shape();
	this.instance.parent = this;
	this.instance.setTransform(256.4,364,1,1,0,0,0,256.4,302.9);
	this.instance.alpha = 0.398;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#002D54","#006FBA"],[0.514,1],2.2,-93.9,2.2,222.1).s().p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
	this.shape.setTransform(337,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup, new cjs.Rectangle(257,0,160,600), null);


(lib.footer = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Artwork
	this.instance = new lib.logoartwork();
	this.instance.parent = this;
	this.instance.setTransform(58.6,42,1.004,1.004);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// black
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("A4/cIMAAAg4PMAx/AAAMAAAA4Pg");
	this.shape.setTransform(160,180);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.footer, new cjs.Rectangle(0,0,320,360), null);


(lib.ctalabelsignup = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#002F53").s().p("AhfCtIAAlZIBVAAQA3AAAZAXQAaAYAAA3QAAA3gaAXQgZAXg3AAIgaAAIAACOgAgkgRIAXAAQAcAAALgLQALgLAAgfQAAgfgLgLQgLgLgcAAIgXAAg");
	this.shape.setTransform(195.7,20.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#002F53").s().p("AhCCYQgYgYAAgtIAAkCIA7AAIAAEFQAAAmAfAAQAgAAAAgmIAAkFIA7AAIAAECQAAAtgYAYQgYAYgrAAQgqAAgYgYg");
	this.shape_1.setTransform(171.1,21.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#002F53").s().p("AAnCtIhLjXIgBAAIAADXIg1AAIAAlZIA3AAIBHDFIABAAIAAjFIA2AAIAAFZg");
	this.shape_2.setTransform(136.5,20.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#002F53").s().p("AhDCbQgWgZAAgpIAAixQAAgnAWgYQAYgaAqAAQApAAAZAcQAWAaAAApIAAAWIg5AAQAAglgIgPQgHgNgSAAQgaAAAAAmIAACxQAAAkAcAAQARAAAHgLQAHgLAAgaIAAghIglAAIAAguIBhAAIAACuIgdAAIgLgaQgOARgMAHQgOAHgTAAQgkAAgWgXg");
	this.shape_3.setTransform(112.3,20.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#002F53").s().p("AgdCtIAAlZIA7AAIAAFZg");
	this.shape_4.setTransform(93.8,20.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#002F53").s().p("AhCCWQgXgbgCgpIA5gIQACAZAJAOQAKANANAAQAQAAAKgIQAJgIAAgPQAAgXgTgWQgIgJgggcQg9gyAAg2QAAgpAYgXQAYgWArAAQAkAAAWAXQAUAXAFAmIg5AGQgBgUgLgKQgIgIgMAAQgcAAAAAiQAAATATAVQAGAHAiAeQA9A0AAAzQAAAqgaAYQgaAXgpAAQgoAAgZgcg");
	this.shape_5.setTransform(76.3,20.9);

	this.arrow = new lib.ctaarrow();
	this.arrow.parent = this;
	this.arrow.setTransform(21.1,21.1,1,1,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ctalabelsignup, new cjs.Rectangle(0,3.1,205.3,36), null);


(lib.background = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 160x600
	this.instance = new lib.ClipGroup();
	this.instance.parent = this;
	this.instance.setTransform(-1.2,666.8,2,2,0,0,0,256.4,333.4);

	this.instance_1 = new lib.BlueGradientImage();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,2,2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.background, new cjs.Rectangle(-514,0,1025.9,1333.9), null);


(lib.ctasignupon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// label
	this.cta_label = new lib.ctalabelsignup();
	this.cta_label.parent = this;
	this.cta_label.setTransform(194.8,40.8,1,1,0,0,0,137.4,26);
	this.cta_label.filters = [new cjs.ColorFilter(0, 0, 0, 1, 255, 255, 255, 0)];
	this.cta_label.cache(-2,1,209,40);

	this.timeline.addTween(cjs.Tween.get(this.cta_label).wait(1));

	// cta_bg
	this.instance = new lib.ctabgtint();
	this.instance.parent = this;
	this.instance.setTransform(300,35,1,1,0,0,0,300,35);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ctasignupon, new cjs.Rectangle(0,0,320,70), null);


(lib.ctasignupoff = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// cta_label
	this.cta_label = new lib.ctalabelsignup();
	this.cta_label.parent = this;
	this.cta_label.setTransform(194.8,41,1,1,0,0,0,137.4,26);

	this.timeline.addTween(cjs.Tween.get(this.cta_label).wait(1));

	// cta_bg
	this.cta_bg = new lib.ctabg();
	this.cta_bg.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.cta_bg).wait(1));

}).prototype = getMCSymbolPrototype(lib.ctasignupoff, new cjs.Rectangle(0,0,320,70), null);


(lib.ctasignup = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.cta_on.alpha = 0;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// cta-on
	this.cta_on = new lib.ctasignupon();
	this.cta_on.parent = this;
	this.cta_on.setTransform(300,35,1,1,0,0,0,300,35);

	this.timeline.addTween(cjs.Tween.get(this.cta_on).wait(1));

	// cta-off
	this.cta_off = new lib.ctasignupoff();
	this.cta_off.parent = this;
	this.cta_off.setTransform(300,35,1,1,0,0,0,300,35);

	this.timeline.addTween(cjs.Tween.get(this.cta_off).wait(1));

}).prototype = getMCSymbolPrototype(lib.ctasignup, new cjs.Rectangle(0,0,320,70), null);


// stage content:
(lib.index = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/**
		 * Squarewave CreateJS Template 1.1 (September 2016)
		 **/
		var root = this;
		
		var stageHeight = stage.canvas.height;
		var stageWidth = stage.canvas.width;
		
		// cta
		var ctaHeight = 70; // need to get this dynamically
		var ctaOpenY = root.cta.y;
		var ctaOffset = 6; // how many pixels of the cta should be visible behind the
		var ctaClosedY = ctaOpenY + ctaHeight - ctaOffset;
		
		
		var mainTl = new TimelineMax();
		
		/**** uncomment to use within creative ******/
		/*
		root.clickthrough.on('mouseover' , onRollOver );
		root.clickthrough.on('mouseout' , onRollOut );
		root.clickthrough.on('click' , onClick );
		*/
		
		this.onInit = function () {
			this.animate();
		}
		
		// banner animation
		this.animate = function () {
			
			mainTl.add('start', 0.2)
		
			// frame 1 animation
			.from(root.facilities, 1, {
				y: stageHeight,
				ease: Strong.easeOut
			}, 'start')
			.from(root.athlete_1, 1.2, {
				scaleX: 1.5,
				scaleY: 1.5,
				alpha: 0,
				ease: Strong.easeOut
			}, 'start')
			.from(root.text_1, 1, {
					alpha: 0,
					y: '+=100',
					ease: Strong.easeOut
				}, 'start+=0.2')
				.from(root.footer, 0.75, {
					y: stageHeight,
					ease: Strong.easeOut
				}, 'start')
				.fromTo(root.cta, 0.75, {
					y: stageHeight
				}, {
					y: ctaClosedY,
					ease: Strong.easeOut
				}, 'start')
		
			// frame 2
			.add('frame2', '+=1')
				.to(root.text_1, 0.5, {
					alpha: 0,
					ease: Strong.easeOut
				}, 'frame2')
				.from(root.text_2, 0.65, {
					alpha: 0,
					y: '+=100',
					ease: Strong.easeOut
				}, 'frame2+=0.75')
				
				// Athlete transition
				.to(root.athlete_1, 1.4, {
					x: '-=' + stageWidth,
					ease: Strong.easeOut
				}, 'frame2+=0.75')
				.from(root.athlete_2, 1.4, {
					x: '+=' + stageWidth,
					ease: Strong.easeOut
				}, 'frame2+=0.75')
				
		
			// transition to end frame 
			.add('frame3', '+=1.5')
				.to(root.text_2, 0.5, {
					alpha: 0,
					ease: Strong.easeOut
				}, 'frame3')
				.to(root.facilities, 0.5, {
				y: stageHeight,
				alpha: 0,
				ease: Strong.easeOut
			}, 'frame3')
			.to(root.athlete_2, 0.5, {
					alpha: 0,
					scaleX: 1.5,
					scaleY: 1.5,
					ease: Strong.easeIn
				}, 'frame3')
				
		
			.add('endFrame')
				.from(root.text_3, 0.65, {
					alpha: 0,
					scaleX: 0.6,
					scaleY: 0.6,
					ease: Strong.easeOut
				}, 'endFrame')
				.to(root.cta, 0.6, {
					y: ctaOpenY,
					ease: Back.easeOut.config(0.5),
					onComplete: this.ctaOpen
				}, 'endFrame+=0.6');
		}
		
		var ctaIsOpen = false;
		// only do the rollover on the cta if it's open/visible
		this.ctaOpen = function () {
			if (!ctaIsOpen) {
				ctaIsOpen = true;
			}
		}
		
		// mouse over/mouse out events
		this.onRollOverEvent = function (e) {
			// wake up creative if asleep //
			if (root.adHelper && !root.adHelper.awake) root.adHelper.wake();
		
			if (ctaIsOpen) TweenMax.to(root.cta.cta_on, 0.2, {
				alpha: 1
			});
		}
		
		this.onRollOutEvent = function (e) {
			if (ctaIsOpen) TweenMax.to(root.cta.cta_on, 0.2, {
				alpha: 0
			});
		}
		
		this.onClickEvent = function (e) {
			console.log("creative-click");
		}
		
		
		
		
		
		
		/**
		 * AD HELPER METHODS
		 *
		 * If everything is setup correctly, you can use
		 * root.adHelper.sleep() & root.adHelper.wake()
		 * to manually control AdHelper.
		 * NOTE: sleep() pauses CreateJS AND TweenLite
		 *
		 **/
		this.adHelper = null; // adhelper reference //
		this.onSlowDown = function () {
			console.log("creative-slowdown");
		}
		
		this.onSleep = function () {
			console.log("creative-sleep");
		}
		
		this.onWake = function () {
			console.log("creative-wake");
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// clickthrough
	this.clickthrough = new lib.clickthrough();
	this.clickthrough.parent = this;
	this.clickthrough.setTransform(160,599.9,1.067,4.8,0,0,0,150,125);
	new cjs.ButtonHelper(this.clickthrough, 0, 1, 2, false, new lib.clickthrough(), 3);

	this.timeline.addTween(cjs.Tween.get(this.clickthrough).wait(1));

	// footer
	this.footer = new lib.footer();
	this.footer.parent = this;
	this.footer.setTransform(0,840);

	this.timeline.addTween(cjs.Tween.get(this.footer).wait(1));

	// cta
	this.cta = new lib.ctasignup();
	this.cta.parent = this;
	this.cta.setTransform(0,770);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// text: headline 3
	this.text_3 = new lib.textheadline3();
	this.text_3.parent = this;
	this.text_3.setTransform(160,401.9,1,1,0,0,0,160,401.9);
	this.text_3.cache(-2,-2,324,1204);

	this.timeline.addTween(cjs.Tween.get(this.text_3).wait(1));

	// athlete_2
	this.athlete_2 = new lib.imgathlete2();
	this.athlete_2.parent = this;
	this.athlete_2.setTransform(159,599.5,1,1,0,0,0,159,599.5);

	this.timeline.addTween(cjs.Tween.get(this.athlete_2).wait(1));

	// athlete_1
	this.athlete_1 = new lib.imgathlete1();
	this.athlete_1.parent = this;
	this.athlete_1.setTransform(160,600,1,1,0,0,0,160,600);

	this.timeline.addTween(cjs.Tween.get(this.athlete_1).wait(1));

	// text: headline 2
	this.text_2 = new lib.textheadline2();
	this.text_2.parent = this;
	this.text_2.cache(16,56,284,210);

	this.timeline.addTween(cjs.Tween.get(this.text_2).wait(1));

	// text: headline 1
	this.text_1 = new lib.textheadline1();
	this.text_1.parent = this;
	this.text_1.cache(16,46,280,255);

	this.timeline.addTween(cjs.Tween.get(this.text_1).wait(1));

	// image: facilities
	this.facilities = new lib.img_facilities_1();
	this.facilities.parent = this;
	this.facilities.setTransform(120,450,1,1,0,0,0,120,450);

	this.timeline.addTween(cjs.Tween.get(this.facilities).wait(1));

	// background
	this.bg = new lib.background();
	this.bg.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-354,599.9,1025.9,1334.1);
// library properties:
lib.properties = {
	width: 320,
	height: 1200,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/BlueGradientImage.png?1481825877197", id:"BlueGradientImage"},
		{src:"images/img_athlete1.png?1481825877197", id:"img_athlete1"},
		{src:"images/img_athlete2.png?1481825877197", id:"img_athlete2"},
		{src:"images/img_facilities.png?1481825877197", id:"img_facilities"}
	],
	preloads: []
};




})(lib = lib||{}, images = images||{}, createjs = createjs||{}, ss = ss||{}, AdobeAn = AdobeAn||{});
var lib, images, createjs, ss, AdobeAn;